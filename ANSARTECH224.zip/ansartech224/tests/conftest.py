import os
import sys

import pytest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from config import TestConfig  # noqa: E402
from ansartech import create_app  # noqa: E402
from ansartech.extensions import db  # noqa: E402
from ansartech.models import User  # noqa: E402
from ansartech.seed import create_company  # noqa: E402


@pytest.fixture
def app(tmp_path):
    class Cfg(TestConfig):
        SQLALCHEMY_DATABASE_URI = "sqlite:///" + str(tmp_path / "test.db")

    application = create_app(Cfg)
    with application.app_context():
        company, _ = create_company("Test SARL", "admin", "Admin@224", must_change_password=False,
                                    address="Kaloum", phone="+224 600")
        db.session.commit()
        application.config["TEST_COMPANY_ID"] = company.id
    yield application
    with application.app_context():
        db.session.remove()
        db.drop_all()


@pytest.fixture
def company_id(app):
    return app.config["TEST_COMPANY_ID"]


@pytest.fixture
def client(app):
    return app.test_client()


def login(client, username="admin", password="Admin@224"):
    return client.post("/connexion", data={"username": username, "password": password}, follow_redirects=True)


@pytest.fixture
def admin(client):
    login(client)
    return client


@pytest.fixture
def make_user(app):
    def _make(username, role, password="Secret123", company=None):
        with app.app_context():
            user = User(username=username, full_name=username.title(), role=role,
                        company_id=company or app.config["TEST_COMPANY_ID"])
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            return user.id
    return _make


@pytest.fixture
def demo(app):
    with app.app_context():
        from ansartech.seed import load_demo_data
        load_demo_data(app.config["TEST_COMPANY_ID"])
