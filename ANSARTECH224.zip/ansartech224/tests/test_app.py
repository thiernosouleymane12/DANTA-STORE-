"""Étape 12 — Tests automatiques de ANSARTECH 224."""
import io
import json

from ansartech.extensions import db
from ansartech.models import (AuditLog, Customer, Document, Message, Product, Purchase,
                              Sale, StockMovement, Supplier, User)

from conftest import login


# ---------------------------------------------------------------- Helpers
def create_product(client, sku="P-001", qty=10, cost=1000, price=1500, min_stock=2):
    return client.post("/produits/nouveau", data={
        "sku": sku, "name": f"Produit {sku}", "purchase_price": cost, "sale_price": price,
        "quantity": qty, "min_stock": min_stock, "unit": "pièce"}, follow_redirects=True)


def product(app, sku="P-001"):
    with app.app_context():
        p = Product.query.filter_by(sku=sku).first()
        return p.id, p.quantity, p.purchase_price


# ---------------------------------------------------------------- Étape 3 : connexion
def test_login_page(client):
    r = client.get("/connexion")
    assert r.status_code == 200
    assert "ANSARTECH 224".encode() in r.data


def test_redirect_when_not_logged(client):
    r = client.get("/")
    assert r.status_code == 302 and "/connexion" in r.headers["Location"]


def test_login_success_and_logout(client):
    r = login(client)
    assert "Tableau de bord".encode() in r.data
    r = client.post("/deconnexion", follow_redirects=True)
    assert "déconnecté".encode() in r.data


def test_login_wrong_password(client):
    r = login(client, password="mauvais")
    assert "incorrect".encode() in r.data


def test_lockout_after_failures(client, app):
    for _ in range(5):
        login(client, password="mauvais")
    r = login(client)  # bon mot de passe mais compte bloqué
    assert "bloqué".encode() in r.data


def test_must_change_password(client, app, make_user):
    with app.app_context():
        uid = make_user("nouveau", "vendeur")
        u = db.session.get(User, uid)
        u.must_change_password = True
        db.session.commit()
    login(client, "nouveau", "Secret123")
    r = client.get("/produits/")
    assert r.status_code == 302 and "mot-de-passe" in r.headers["Location"]
    r = client.post("/mot-de-passe", data={"current_password": "Secret123", "new_password": "court",
                                           "confirm_password": "court"}, follow_redirects=True)
    assert "8 caractères".encode() in r.data
    r = client.post("/mot-de-passe", data={"current_password": "Secret123", "new_password": "Nouveau2026",
                                           "confirm_password": "Nouveau2026"}, follow_redirects=True)
    assert "modifié".encode() in r.data
    assert client.get("/produits/").status_code == 200


def test_open_redirect_blocked(client):
    r = client.post("/connexion?next=https://evil.com", data={"username": "admin", "password": "Admin@224"})
    assert "evil.com" not in r.headers["Location"]


def test_user_management(admin, app):
    r = admin.post("/utilisateurs/nouveau", data={"username": "vendeur1", "full_name": "Aïssatou Bah",
                                                 "role": "vendeur", "password": "Vente2026"}, follow_redirects=True)
    assert "Utilisateur enregistré".encode() in r.data
    r = admin.post("/utilisateurs/nouveau", data={"username": "vendeur1", "full_name": "Doublon",
                                                 "role": "vendeur", "password": "Vente2026"}, follow_redirects=True)
    assert "déjà utilisé".encode() in r.data
    with app.app_context():
        uid = User.query.filter_by(username="vendeur1").first().id
    admin.post(f"/utilisateurs/{uid}/statut")
    with app.app_context():
        assert db.session.get(User, uid).is_active_account is False


def test_roles(client, make_user):
    make_user("vend", "vendeur")
    login(client, "vend", "Secret123")
    assert client.get("/analyses/").status_code == 403
    assert client.get("/parametres/").status_code == 403
    assert client.get("/utilisateurs").status_code == 403
    assert client.get("/produits/nouveau").status_code == 403
    assert client.get("/ventes/nouvelle").status_code == 200
    assert client.get("/produits/").status_code == 200


# ---------------------------------------------------------------- Étape 4 : toutes les pages
def test_all_pages_render(admin, demo, app):
    with app.app_context():
        sale_id = Sale.query.first().id
        purchase_id = Purchase.query.first().id
        product_id = Product.query.first().id
        supplier_id = Supplier.query.first().id
        customer_id = Customer.query.first().id
    urls = ["/", "/produits/", "/produits/nouveau", f"/produits/{product_id}", f"/produits/{product_id}/modifier",
            "/produits/categories", "/produits/export", "/produits/api/recherche?q=Sams",
            "/stock/", "/stock/mouvement", "/stock/inventaire", "/stock/export",
            "/achats/", "/achats/nouveau", f"/achats/{purchase_id}", "/achats/fournisseurs",
            "/achats/fournisseurs/nouveau", f"/achats/fournisseurs/{supplier_id}", "/achats/export",
            "/ventes/", "/ventes/nouvelle", f"/ventes/{sale_id}", f"/ventes/{sale_id}/facture",
            f"/ventes/{sale_id}/facture?format=ticket", "/ventes/clients", "/ventes/clients/nouveau",
            f"/ventes/clients/{customer_id}", "/ventes/export?statut=payee",
            "/analyses/", "/analyses/?jours=365", "/analyses/commande-suggeree.csv",
            "/archives/", "/archives/messages", "/archives/messages?boite=envoyes", "/archives/messages/nouveau",
            "/parametres/", "/parametres/journal", "/parametres/sauvegarde",
            "/utilisateurs", "/utilisateurs/nouveau", "/profil", "/mot-de-passe",
            "/ventes/?q=Sow&du=2020-01-01&au=2030-01-01"]
    for url in urls:
        r = admin.get(url)
        assert r.status_code == 200, url


def test_404(admin):
    assert admin.get("/produits/99999").status_code == 404
    assert admin.get("/page-inexistante").status_code == 404


# ---------------------------------------------------------------- Étape 5 : produits
def test_product_create_and_duplicate(admin, app):
    r = create_product(admin)
    assert "Produit enregistré".encode() in r.data
    _, qty, _ = product(app)
    assert qty == 10
    r = create_product(admin)
    assert "existe déjà".encode() in r.data
    r = admin.post("/produits/nouveau", data={"sku": "", "name": ""}, follow_redirects=True)
    assert "obligatoire".encode() in r.data


def test_product_search_api(admin, app):
    create_product(admin, "TEL-9")
    data = admin.get("/produits/api/recherche?q=TEL").get_json()
    assert data["results"][0]["sku"] == "TEL-9"


def test_product_delete_and_archive(admin, app):
    create_product(admin, "DEL-1")
    pid, _, _ = product(app, "DEL-1")
    admin.post(f"/produits/{pid}/archiver")
    with app.app_context():
        assert db.session.get(Product, pid).is_active is False
    admin.post(f"/produits/{pid}/supprimer")
    with app.app_context():
        assert db.session.get(Product, pid) is None


# ---------------------------------------------------------------- Étape 6 : stocks
def test_stock_movements(admin, app):
    create_product(admin)
    pid, _, _ = product(app)
    admin.post("/stock/mouvement", data={"product_id": pid, "movement_type": "entree", "quantity": 5, "reason": "Test"})
    assert product(app)[1] == 15
    admin.post("/stock/mouvement", data={"product_id": pid, "movement_type": "sortie", "quantity": 3, "reason": "Casse"})
    assert product(app)[1] == 12
    r = admin.post("/stock/mouvement", data={"product_id": pid, "movement_type": "sortie", "quantity": 100,
                                            "reason": "Trop"}, follow_redirects=True)
    assert "Stock insuffisant".encode() in r.data
    assert product(app)[1] == 12
    admin.post("/stock/mouvement", data={"product_id": pid, "movement_type": "ajustement", "quantity": 7, "reason": "Comptage"})
    assert product(app)[1] == 7
    admin.post("/stock/inventaire", data={f"count_{pid}": "9"})
    assert product(app)[1] == 9
    with app.app_context():
        assert StockMovement.query.filter_by(product_id=pid).count() == 5


# ---------------------------------------------------------------- Étape 7 : achats
def test_purchase_flow(admin, app):
    create_product(admin, qty=0, cost=1000)
    pid, _, _ = product(app)
    admin.post("/achats/fournisseurs/nouveau", data={"name": "Fournisseur Test", "phone": "+224 600"})
    with app.app_context():
        sid = Supplier.query.first().id
    r = admin.post("/achats/nouveau", data={"supplier_id": sid, "product_id[]": [pid], "quantity[]": ["20"],
                                           "price[]": ["1200"], "amount_paid": "10000"}, follow_redirects=True)
    assert "enregistré".encode() in r.data
    assert product(app)[1] == 0  # pas encore reçu
    with app.app_context():
        purchase = Purchase.query.first()
        assert purchase.total == 24000 and purchase.balance == 14000
        purchase_id = purchase.id
    admin.post(f"/achats/{purchase_id}/recevoir", data={"update_cost": "1"})
    _, qty, cost = product(app)
    assert qty == 20 and cost == 1200
    admin.post(f"/achats/{purchase_id}/recevoir", data={"update_cost": "1"})  # double réception refusée
    assert product(app)[1] == 20
    admin.post(f"/achats/{purchase_id}/paiement", data={"amount": "14000"})
    with app.app_context():
        assert db.session.get(Purchase, purchase_id).balance == 0


def test_purchase_requires_lines(admin, app):
    admin.post("/achats/fournisseurs/nouveau", data={"name": "F"})
    with app.app_context():
        sid = Supplier.query.first().id
    r = admin.post("/achats/nouveau", data={"supplier_id": sid}, follow_redirects=True)
    assert "au moins un produit".encode() in r.data


# ---------------------------------------------------------------- Étape 8 : ventes
def test_sale_flow(admin, app):
    create_product(admin, qty=10, cost=1000, price=1500)
    pid, _, _ = product(app)
    r = admin.post("/ventes/nouvelle", data={"product_id[]": [pid], "quantity[]": ["4"], "price[]": ["1500"],
                                            "payment_method": "orange_money", "discount": "0",
                                            "amount_paid": "10000"}, follow_redirects=True)
    assert "Monnaie à rendre : 4 000".encode() in r.data
    assert product(app)[1] == 6
    with app.app_context():
        sale = Sale.query.first()
        assert sale.total == 6000 and sale.status == "payee" and sale.profit == 2000
        sale_id = sale.id
    r = admin.get(f"/ventes/{sale_id}/facture")
    assert b"FACTURE" in r.data and b"6 000" in r.data
    r = admin.post(f"/ventes/{sale_id}/annuler", data={"reason": "Erreur"}, follow_redirects=True)
    assert "remis en stock".encode() in r.data
    assert product(app)[1] == 10


def test_sale_insufficient_stock(admin, app):
    create_product(admin, qty=2)
    pid, _, _ = product(app)
    r = admin.post("/ventes/nouvelle", data={"product_id[]": [pid, pid], "quantity[]": ["2", "1"],
                                            "price[]": ["1500", "1500"], "payment_method": "especes"},
                   follow_redirects=True)
    assert "Stock insuffisant".encode() in r.data
    assert product(app)[1] == 2
    with app.app_context():
        assert Sale.query.count() == 0


def test_sale_credit_needs_customer_and_payment(admin, app):
    create_product(admin, qty=5, price=1000)
    pid, _, _ = product(app)
    data = {"product_id[]": [pid], "quantity[]": ["2"], "price[]": ["1000"], "payment_method": "credit",
            "amount_paid": "500"}
    r = admin.post("/ventes/nouvelle", data=data, follow_redirects=True)
    assert "client identifié".encode() in r.data
    data["new_customer_name"] = "Mamadou Diallo"
    admin.post("/ventes/nouvelle", data=data)
    with app.app_context():
        sale = Sale.query.first()
        assert sale.status == "partielle" and sale.balance == 1500 and sale.customer.name == "Mamadou Diallo"
        sale_id = sale.id
    admin.post(f"/ventes/{sale_id}/paiement", data={"amount": "1500"})
    with app.app_context():
        assert db.session.get(Sale, sale_id).status == "payee"


def test_sale_with_tax_and_discount(admin, app):
    admin.post("/parametres/", data={"name": "Ma Boutique", "currency": "GNF", "tax_rate": "18",
                                    "invoice_prefix": "FAC", "purchase_prefix": "ACH"})
    create_product(admin, qty=5, price=10000)
    pid, _, _ = product(app)
    admin.post("/ventes/nouvelle", data={"product_id[]": [pid], "quantity[]": ["1"], "price[]": ["10000"],
                                        "payment_method": "especes", "discount": "1000"})
    with app.app_context():
        sale = Sale.query.first()
        assert sale.tax_amount == 1620 and sale.total == 10620
        assert sale.invoice_number.startswith("FAC-")


def test_invoice_numbers_increment(admin, app):
    create_product(admin, qty=10)
    pid, _, _ = product(app)
    for _ in range(3):
        admin.post("/ventes/nouvelle", data={"product_id[]": [pid], "quantity[]": ["1"], "price[]": ["1500"],
                                            "payment_method": "especes"})
    with app.app_context():
        numbers = sorted(s.invoice_number for s in Sale.query.all())
    assert numbers[0].endswith("00001") and numbers[2].endswith("00003")


# ---------------------------------------------------------------- Étape 9 : analyses
def test_analytics_recommendations(admin, demo, app):
    r = admin.get("/analyses/?jours=90")
    assert "Recommandations".encode() in r.data
    assert "Urgent".encode() in r.data  # la clé USB est en rupture
    csv_data = admin.get("/analyses/commande-suggeree.csv?jours=90").data.decode("utf-8-sig")
    assert "ACC-003" in csv_data


# ---------------------------------------------------------------- Étape 10 : archives & messages
def test_documents(admin, app):
    r = admin.post("/archives/ajouter", data={"title": "Contrat", "category": "contrat",
                                             "file": (io.BytesIO(b"%PDF-1.4 test"), "contrat.pdf")},
                   content_type="multipart/form-data", follow_redirects=True)
    assert "archivé".encode() in r.data
    with app.app_context():
        doc_id = Document.query.first().id
    r = admin.get(f"/archives/{doc_id}/telecharger")
    assert r.data == b"%PDF-1.4 test"
    r = admin.post("/archives/ajouter", data={"file": (io.BytesIO(b"x"), "virus.exe")},
                   content_type="multipart/form-data", follow_redirects=True)
    assert "non autorisé".encode() in r.data
    admin.post(f"/archives/{doc_id}/supprimer")
    with app.app_context():
        assert Document.query.count() == 0


def test_messages(client, app, make_user):
    uid = make_user("caissier", "vendeur")
    login(client)
    client.post("/archives/messages/nouveau", data={"recipient_id": str(uid), "subject": "Inventaire",
                                                   "body": "Inventaire samedi."})
    client.post("/deconnexion")
    login(client, "caissier", "Secret123")
    r = client.get("/archives/messages")
    assert "Inventaire".encode() in r.data
    with app.app_context():
        mid = Message.query.first().id
    client.get(f"/archives/messages/{mid}")
    with app.app_context():
        assert db.session.get(Message, mid).is_read


# ---------------------------------------------------------------- Étape 11 : paramètres & sécurité
def test_settings_and_backup(admin, demo, app):
    r = admin.post("/parametres/", data={"name": "Boutique Kaloum", "currency": "GNF", "tax_rate": "0",
                                        "invoice_prefix": "FK", "purchase_prefix": "AK",
                                        "address": "Kaloum", "invoice_color": "#1d5fa8"}, follow_redirects=True)
    assert "enregistrés".encode() in r.data
    r = admin.post("/parametres/", data={"name": "X", "currency": "GNF", "tax_rate": "150",
                                        "invoice_prefix": "FK", "purchase_prefix": "AK"}, follow_redirects=True)
    assert "entre 0 et 100".encode() in r.data
    data = json.loads(admin.get("/parametres/sauvegarde").data)
    assert data["parametres"]["company_name"] == "Boutique Kaloum"
    assert len(data["produits"]) == 12
    assert all("password_hash" not in u for u in data["utilisateurs"])
    with app.app_context():
        assert AuditLog.query.filter_by(action="parametres").count() == 1


def test_csrf_protection(tmp_path):
    from config import TestConfig
    from ansartech import create_app

    class Cfg(TestConfig):
        WTF_CSRF_ENABLED = True
        SQLALCHEMY_DATABASE_URI = "sqlite:///" + str(tmp_path / "csrf.db")

    app = create_app(Cfg)
    client = app.test_client()
    r = client.post("/connexion", data={"username": "admin", "password": "Admin@224"})
    assert r.status_code == 400


def test_security_headers(client):
    r = client.get("/connexion")
    assert r.headers["X-Frame-Options"] == "SAMEORIGIN"
    assert r.headers["X-Content-Type-Options"] == "nosniff"


def test_postgres_url_conversion(monkeypatch):
    import config
    monkeypatch.setenv("DATABASE_URL", "postgres://u:p@h:5432/db")
    assert config._database_url() == "postgresql://u:p@h:5432/db"
