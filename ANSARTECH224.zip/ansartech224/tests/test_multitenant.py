"""Tests multi-entreprises : isolation des données, plateforme, adresses et factures."""
import io
import json
from datetime import timedelta

import pytest

from ansartech.extensions import db
from ansartech.models import Company, Product, Sale, User, utcnow
from ansartech.seed import create_company

from conftest import login

PNG = (b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01\x00\x00\x00\x01\x08\x06\x00\x00\x00\x1f\x15\xc4"
       b"\x89\x00\x00\x00\rIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00\x05\x18\xd8N\x00\x00\x00\x00IEND\xaeB`\x82")


@pytest.fixture
def company_b(app):
    with app.app_context():
        company, _ = create_company("Pharmacie Matam", "matam.admin", "Matam2026", must_change_password=False,
                                    address="Matam", city="Conakry")
        db.session.commit()
        return company.id


def sell_one(client, app, sku="P-1", price=1000):
    client.post("/produits/nouveau", data={"sku": sku, "name": "Produit " + sku, "purchase_price": 500,
                                           "sale_price": price, "quantity": 10, "min_stock": 1})
    with app.app_context():
        pid = Product.query.execution_options(skip_tenant=True).filter_by(sku=sku).order_by(Product.id.desc()).first().id
    client.post("/ventes/nouvelle", data={"product_id[]": [pid], "quantity[]": ["1"], "price[]": [str(price)],
                                          "payment_method": "especes", "new_customer_name": "Client " + sku})
    return pid


# ---------------------------------------------------------------- Isolation
def test_data_isolation_between_companies(client, app, company_b):
    login(client)  # entreprise A
    pid = sell_one(client, app, "SECRET-A", 777000)
    client.post("/achats/fournisseurs/nouveau", data={"name": "Fournisseur A"})
    client.post("/archives/ajouter", data={"title": "Contrat A", "file": (io.BytesIO(b"%PDF a"), "a.pdf")},
                content_type="multipart/form-data")
    with app.app_context():
        sale = Sale.query.execution_options(skip_tenant=True).first()
        sale_id, customer_id = sale.id, sale.customer_id
    client.post("/deconnexion")

    login(client, "matam.admin", "Matam2026")  # entreprise B
    for url in ["/produits/", "/ventes/", "/ventes/clients", "/achats/fournisseurs", "/archives/", "/stock/",
                "/", "/analyses/?jours=365"]:
        body = client.get(url).data
        for secret in (b"SECRET-A", b"Client SECRET-A", b"Fournisseur A", b"Contrat A", b"777 000"):
            assert secret not in body, (url, secret)
    for url in [f"/produits/{pid}", f"/ventes/{sale_id}", f"/ventes/{sale_id}/facture",
                f"/ventes/clients/{customer_id}", "/archives/1/telecharger"]:
        assert client.get(url).status_code == 404, url
    assert client.get("/produits/api/recherche?q=SECRET").get_json()["results"] == []

    # Impossible de vendre ou modifier le produit d'une autre entreprise
    r = client.post("/ventes/nouvelle", data={"product_id[]": [pid], "quantity[]": ["1"], "price[]": ["1"],
                                              "payment_method": "especes"}, follow_redirects=True)
    assert "au moins un produit".encode() in r.data
    assert client.post(f"/produits/{pid}/modifier", data={"sku": "HACK", "name": "x"}).status_code == 404
    assert client.post(f"/ventes/{sale_id}/annuler", data={"reason": "x"}).status_code == 404

    backup = json.loads(client.get("/parametres/sauvegarde").data)
    assert backup["produits"] == [] and backup["ventes"] == [] and backup["lignes_vente"] == []
    assert all(u["company_id"] == company_b for u in backup["utilisateurs"])
    with app.app_context():
        assert Product.query.execution_options(skip_tenant=True).get(pid).sku == "SECRET-A"


def test_same_sku_and_numbering_per_company(client, app, company_b):
    login(client)
    sell_one(client, app, "TEL-1")
    client.post("/deconnexion")
    login(client, "matam.admin", "Matam2026")
    sell_one(client, app, "TEL-1")
    with app.app_context():
        sales = Sale.query.execution_options(skip_tenant=True).all()
        assert len(sales) == 2
        assert {s.company_id for s in sales} == {app.config["TEST_COMPANY_ID"], company_b}
        assert all(s.invoice_number.endswith("-00001") for s in sales)


def test_usernames_unique_across_platform(admin, company_b):
    r = admin.post("/utilisateurs/nouveau", data={"username": "matam.admin", "full_name": "Copie",
                                                 "role": "vendeur", "password": "Vente2026"}, follow_redirects=True)
    assert "déjà utilisé".encode() in r.data


def test_company_admin_cannot_create_superadmin(admin, app):
    r = admin.post("/utilisateurs/nouveau", data={"username": "pirate", "full_name": "Pirate",
                                                 "role": "superadmin", "password": "Pirate2026"}, follow_redirects=True)
    assert "Rôle invalide".encode() in r.data
    with app.app_context():
        assert User.query.filter_by(username="pirate").first() is None


def test_max_users_limit(admin, app, company_id):
    with app.app_context():
        db.session.get(Company, company_id).max_users = 1
        db.session.commit()
    r = admin.post("/utilisateurs/nouveau", data={"username": "vendeur2", "full_name": "V",
                                                 "role": "vendeur", "password": "Vente2026"}, follow_redirects=True)
    assert "Limite atteinte".encode() in r.data


def test_company_users_cannot_access_platform(admin):
    assert admin.get("/plateforme/").status_code == 403
    assert admin.post("/plateforme/entreprises/nouvelle", data={}).status_code == 403


# ---------------------------------------------------------------- Plateforme (super-admin)
def test_superadmin_creates_company(client, app):
    r = login(client, "super", "Super@224")
    assert "Entreprises clientes".encode() in r.data
    assert client.get("/").status_code == 302  # pas de données d'entreprise hors mode support
    end = (utcnow().date() + timedelta(days=60)).isoformat()
    r = client.post("/plateforme/entreprises/nouvelle", data={
        "name": "Quincaillerie Ratoma", "address": "Ratoma, Conakry", "city": "Conakry", "country": "Guinée",
        "phone": "+224 621", "subscription_end": end, "max_users": "3",
        "admin_username": "ratoma", "admin_password": "Ratoma2026", "admin_full_name": "Mamadou"},
        follow_redirects=True)
    assert "créée".encode() in r.data
    with app.app_context():
        company = Company.query.filter_by(name="Quincaillerie Ratoma").first()
        assert company.code == "quincaillerie-ratoma" and company.max_users == 3
        assert User.query.filter_by(username="ratoma").first().must_change_password
    r = client.post("/plateforme/entreprises/nouvelle", data={
        "name": "Autre", "max_users": "3", "admin_username": "ratoma", "admin_password": "Ratoma2026"},
        follow_redirects=True)
    assert "déjà utilisé".encode() in r.data

    client.post("/deconnexion")
    r = login(client, "ratoma", "Ratoma2026")
    assert "Sécurisez votre compte".encode() in r.data


def test_suspend_and_expire_company(client, app, company_id):
    login(client)
    assert client.get("/produits/").status_code == 200
    with app.app_context():
        db.session.get(Company, company_id).is_active = False
        db.session.commit()
    r = client.get("/produits/", follow_redirects=True)
    assert "suspendu".encode() in r.data
    r = login(client)
    assert "suspendu".encode() in r.data

    with app.app_context():
        company = db.session.get(Company, company_id)
        company.is_active = True
        company.subscription_end = utcnow().date() - timedelta(days=1)
        db.session.commit()
    r = login(client)
    assert "expiré".encode() in r.data

    login(client, "super", "Super@224")
    client.post(f"/plateforme/entreprises/{company_id}/prolonger", data={"months": "3"})
    client.post("/deconnexion")
    r = login(client)
    assert "Tableau de bord".encode() in r.data


def test_superadmin_support_mode(client, app, company_id):
    login(client)
    sell_one(client, app, "SUPPORT-1")
    client.post("/deconnexion")
    login(client, "super", "Super@224")
    r = client.post(f"/plateforme/entreprises/{company_id}/support", follow_redirects=True)
    assert "Mode support".encode() in r.data and "Test SARL".encode() in r.data
    assert "SUPPORT-1".encode() in client.get("/produits/").data
    assert client.get("/parametres/").status_code == 200
    r = client.post("/plateforme/quitter-support", follow_redirects=True)
    assert "Entreprises clientes".encode() in r.data
    assert client.get("/produits/").status_code == 302


def test_superadmin_resets_user_password(client, app, company_id):
    with app.app_context():
        uid = User.query.filter_by(username="admin").first().id
    login(client, "super", "Super@224")
    client.post(f"/plateforme/entreprises/{company_id}/utilisateurs/{uid}/mot-de-passe",
                data={"password": "Nouveau2026"})
    client.post("/deconnexion")
    r = login(client, "admin", "Nouveau2026")
    assert "Sécurisez votre compte".encode() in r.data


def test_platform_pages_render(client, app, company_id):
    login(client, "super", "Super@224")
    for url in ["/plateforme/", "/plateforme/?statut=actives", "/plateforme/entreprises/nouvelle",
                f"/plateforme/entreprises/{company_id}", f"/plateforme/entreprises/{company_id}/modifier",
                "/profil", "/mot-de-passe"]:
        assert client.get(url).status_code == 200, url


# ---------------------------------------------------------------- Adresses, logo et facture
def test_company_address_logo_and_invoice(admin, app, company_id):
    r = admin.post("/parametres/", data={
        "name": "Boutique Kaloum", "activity": "Téléphonie", "address": "Avenue de la République",
        "city": "Conakry", "country": "Guinée", "phone": "+224 622 00 00 00", "email": "contact@kaloum.gn",
        "rccm": "GN.TCC.2026.B.123", "nif": "NIF-999", "currency": "GNF", "tax_rate": "0",
        "invoice_prefix": "BK", "purchase_prefix": "AB", "invoice_title": "Facture client",
        "invoice_address": "Magasin : Marché Niger, Kaloum", "invoice_phone": "+224 655 11 11 11",
        "invoice_payment_info": "Orange Money : 610 00 00 00", "invoice_terms": "Garantie 6 mois",
        "invoice_color": "#c62f2f", "show_logo_on_invoice": "1",
        "logo": (io.BytesIO(PNG), "logo.png")}, content_type="multipart/form-data", follow_redirects=True)
    assert "enregistrés".encode() in r.data
    assert admin.get("/parametres/logo").data == PNG

    sell_one(admin, app, "INV-1")
    with app.app_context():
        sale = Sale.query.first()
        assert sale.invoice_number.startswith("BK-")
    html = admin.get(f"/ventes/{sale.id}/facture").data.decode()
    for expected in ["Boutique Kaloum", "Magasin : Marché Niger, Kaloum", "+224 655 11 11 11",
                     "Orange Money : 610 00 00 00", "Garantie 6 mois", "GN.TCC.2026.B.123", "NIF-999",
                     "FACTURE CLIENT", "#c62f2f", "/parametres/logo"]:
        assert expected in html, expected

    # Logo invalide (faux PNG) refusé
    r = admin.post("/parametres/", data={"name": "Boutique Kaloum", "currency": "GNF", "tax_rate": "0",
                                        "invoice_prefix": "BK", "purchase_prefix": "AB", "invoice_color": "#c62f2f",
                                        "logo": (io.BytesIO(b"<svg onload=alert(1)>"), "logo.png")},
                   content_type="multipart/form-data", follow_redirects=True)
    assert "PNG, JPG ou WEBP".encode() in r.data


def test_invoice_falls_back_to_company_address(admin, app):
    sell_one(admin, app, "INV-2")
    with app.app_context():
        sale_id = Sale.query.first().id
    html = admin.get(f"/ventes/{sale_id}/facture").data.decode()
    assert "Test SARL" in html and "Kaloum" in html and "+224 600" in html


def test_logo_of_other_company_not_served(client, app, company_b):
    with app.app_context():
        company = db.session.get(Company, company_b)
        company.logo, company.logo_mimetype = PNG, "image/png"
        db.session.commit()
    login(client)
    assert client.get("/parametres/logo").status_code == 404


def test_aggregates_are_isolated(client, app, company_b):
    """Les totaux calculés (créances, chiffre d'affaires) ne mélangent jamais deux entreprises."""
    login(client)
    client.post("/produits/nouveau", data={"sku": "AGG", "name": "Agg", "purchase_price": 1,
                                           "sale_price": 900000, "quantity": 5})
    with app.app_context():
        pid = Product.query.execution_options(skip_tenant=True).filter_by(sku="AGG").first().id
    client.post("/ventes/nouvelle", data={"product_id[]": [pid], "quantity[]": ["1"], "price[]": ["900000"],
                                          "payment_method": "credit", "amount_paid": "0",
                                          "new_customer_name": "Débiteur"})
    assert b"900 000 GNF" in client.get("/").data
    client.post("/deconnexion")
    login(client, "matam.admin", "Matam2026")
    body = client.get("/").data
    assert b"900 000" not in body
    from ansartech.tenancy import tenant_context
    with app.app_context(), tenant_context(company_b):
        receivables = db.session.query(db.func.coalesce(db.func.sum(Sale.total - Sale.amount_paid), 0)).filter(
            Sale.status.in_(["partielle", "impayee"])).scalar()
        assert receivables == 0
