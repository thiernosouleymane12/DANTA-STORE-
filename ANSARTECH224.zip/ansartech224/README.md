# ANSARTECH 224 — Logiciel de gestion commerciale

Gestion des produits, stocks, achats, ventes, factures, analyses et archives.
**Multi-entreprises** : une seule installation, plusieurs entreprises clientes, chacune avec ses
données isolées, ses utilisateurs, ses adresses, son logo et sa facture personnalisée.
Fonctionne sur ordinateur, tablette et téléphone (navigateur web). Prêt pour Render.

Technologies : Python 3.12 · Flask · PostgreSQL (Render) ou SQLite (local) · HTML/CSS/JS sans framework.

---

## 1. Structure du projet (emplacement de chaque fichier)

```
ansartech224/
├── app.py                     ← point d'entrée (gunicorn app:app)
├── config.py                  ← configuration (base, sécurité, admin)
├── requirements.txt           ← dépendances Python
├── render.yaml                ← déploiement automatique Render
├── .python-version            ← version Python (3.12.7)
├── .env.example               ← modèle de variables d'environnement
├── .gitignore
├── ansartech/
│   ├── __init__.py            ← Étape 1 : création de l'application
│   ├── extensions.py          ← base de données, connexion, CSRF
│   ├── models.py              ← Étape 2 : toutes les tables
│   ├── tenancy.py             ← multi-entreprises : isolation automatique des données
│   ├── seed.py                ← super-admin, création d'entreprise, démonstration
│   ├── utils.py               ← fonctions communes (stock, rôles, CSV…)
│   ├── routes/
│   │   ├── platform.py        ← espace Plateforme (vos entreprises clientes)
│   │   ├── auth.py            ← Étape 3 : connexion, utilisateurs
│   │   ├── dashboard.py       ← Étape 4 : tableau de bord
│   │   ├── products.py        ← Étape 5 : produits, catégories
│   │   ├── stock.py           ← Étape 6 : mouvements, inventaire
│   │   ├── purchases.py       ← Étape 7 : achats, fournisseurs
│   │   ├── sales.py           ← Étape 8 : ventes, clients, factures
│   │   ├── analytics.py       ← Étape 9 : analyses, recommandations
│   │   ├── archives.py        ← Étape 10 : documents, messagerie
│   │   └── settings.py        ← Étape 11 : fiche entreprise, logo, facture, journal, sauvegarde
│   ├── templates/             ← pages HTML (une par écran)
│   └── static/                ← css/style.css, js/app.js, js/chart.umd.min.js, img/logo.svg
└── tests/                     ← Étape 12 : 44 tests automatiques
    ├── conftest.py
    ├── test_app.py            ← fonctionnement des 12 modules
    └── test_multitenant.py    ← isolation entre entreprises, plateforme, factures
```

## 2. Fonctionnalités

| Module | Contenu |
|---|---|
| Utilisateurs | 3 rôles (Administrateur, Gestionnaire, Vendeur), blocage après 5 échecs, mot de passe à changer à la 1re connexion |
| Tableau de bord | Ventes du jour/mois, bénéfice, valeur du stock, créances, graphique 14 jours, alertes |
| Produits | Code, code-barres, catégorie, prix d'achat/vente, marge, stock minimum, archivage, export Excel |
| Stocks | Entrées, sorties, ajustements, inventaire physique, historique complet tracé |
| Achats | Fournisseurs, bons de commande, réception (stock + prix d'achat mis à jour), paiements, dettes |
| Ventes | Caisse rapide (recherche / lecteur code-barres), remise, TVA, Orange Money, MTN MoMo, crédit client, monnaie à rendre, annulation avec remise en stock |
| Factures | Facture A4 et ticket de caisse 80 mm, impression ou PDF |
| Analyses | CA, bénéfice, panier moyen, top produits, catégories, jours forts, réapprovisionnement suggéré (30 jours), stock dormant, marges faibles |
| Archives | Stockage de documents (PDF, images, Word, Excel), messagerie interne, exports CSV |
| Paramètres | Infos entreprise, devise (GNF), TVA, préfixes de factures, journal d'activité, sauvegarde JSON |

## 3. Fonctionnement multi-entreprises

Il y a deux niveaux de comptes :

| Compte | Qui | Ce qu'il voit |
|---|---|---|
| **Super-admin plateforme** | Vous (ANSARTECH 224) | L'espace **Plateforme** : liste des entreprises, création, abonnements, suspension, réinitialisation des mots de passe |
| **Administrateur d'entreprise** | Votre client | Uniquement les données de son entreprise : produits, ventes, utilisateurs, paramètres |

- **Isolation garantie** : chaque lecture et chaque écriture est automatiquement filtrée sur l'entreprise de l'utilisateur. Changer un numéro dans l'adresse de la page ne permet jamais de voir les données d'une autre entreprise (testé automatiquement).
- **Abonnements** : date de fin et nombre maximum d'utilisateurs par entreprise. Après la date, ou si vous suspendez l'entreprise, ses utilisateurs ne peuvent plus se connecter. Bouton « Prolonger » (+1, 3, 6 ou 12 mois).
- **Mode support** : depuis la fiche d'une entreprise, « Ouvrir son espace » vous permet d'aider le client dans son propre espace (bandeau jaune visible, action tracée dans le journal).
- **Identifiants** : uniques sur toute la plateforme (ex. `kaloum.admin`, `matam.caisse`).

### Proposer le logiciel à un nouveau client
1. Connectez-vous avec votre compte super-admin → **Nouvelle entreprise**.
2. Renseignez le nom, l'adresse, le téléphone, la fin d'abonnement, le nombre d'utilisateurs, puis l'identifiant et un mot de passe provisoire pour son administrateur.
3. Donnez au client l'adresse du site, son identifiant et son mot de passe provisoire. À la 1re connexion, il choisit son propre mot de passe.
4. Le client complète **Paramètres** : adresses, logo, informations de facture, puis crée ses vendeurs et gestionnaires.

### Adresses et facture de chaque entreprise (Paramètres)
- **Identité** : nom, activité, RCCM, NIF.
- **Adresse principale** : adresse, ville, pays, téléphone, e-mail, site web.
- **Logo** : PNG, JPG ou WEBP (1 Mo max), affiché dans le menu et sur les factures.
- **Facture** : titre du document, couleur, adresse de facturation différente (ex. magasin + dépôt, sur plusieurs lignes), téléphone et e-mail de facturation, moyens de paiement acceptés (Orange Money, MTN MoMo, banque), conditions/garantie, pied de page, devise, TVA, préfixe de numérotation.
Si l'adresse, le téléphone ou l'e-mail de facturation sont vides, ceux de l'entreprise sont utilisés. Chaque entreprise a sa propre numérotation (FAC-2026-00001…).

## 4. Installation sur votre ordinateur (test local)

Prérequis : Python 3.12 (https://www.python.org/downloads/ — cochez « Add Python to PATH » sous Windows).

```bash
cd ansartech224
python -m venv .venv
# Windows :
.venv\Scripts\activate
# macOS / Linux :
source .venv/bin/activate

pip install -r requirements.txt
copy .env.example .env        # Windows   (macOS/Linux : cp .env.example .env)
python app.py
```

Ouvrez **http://127.0.0.1:5000**
- Super-admin plateforme : `admin` / `Admin@224` (à changer immédiatement).
- Entreprise de démonstration (si `DEMO_DATA=1`) : `demo` / `Demo@2026`.

Pour l'ouvrir depuis votre téléphone sur le même Wi-Fi : http://ADRESSE-IP-DU-PC:5000

Lancer les tests :
```bash
python -m pytest -q
```

## 5. Déploiement sur Render (en ligne, ordinateur + téléphone)

1. Créez un compte sur https://github.com et un dépôt **ansartech224** (privé conseillé).
2. Envoyez le dossier :
   ```bash
   cd ansartech224
   git init
   git add .
   git commit -m "ANSARTECH 224"
   git branch -M main
   git remote add origin https://github.com/VOTRE-COMPTE/ansartech224.git
   git push -u origin main
   ```
3. Sur https://render.com : **New → Blueprint** → choisissez le dépôt. Render lit `render.yaml` et crée :
   - la base PostgreSQL `ansartech224-db`
   - le site web `ansartech224`
4. Render vous demande **ADMIN_PASSWORD** : c'est le mot de passe de **votre** compte super-admin (identifiant `admin`). Choisissez-le solide.
5. Cliquez **Apply**. Après 3 à 5 minutes, le site est en ligne : `https://ansartech224.onrender.com`
6. Connectez-vous avec `admin` et le mot de passe choisi : vous arrivez sur l'espace **Plateforme**. Créez vos entreprises clientes.

Sur téléphone : ouvrez l'adresse dans Chrome puis « Ajouter à l'écran d'accueil » : le logiciel s'ouvre comme une application.

Pour créer l'entreprise de démonstration (`demo` / `Demo@2026`), mettez `DEMO_DATA` à `1` dans Render → Environment. Supprimez-la ou suspendez-la avant d'ouvrir le site à vos clients.

> **Vous aviez déjà déployé la version précédente ?** La structure de la base a changé (multi-entreprises). Si elle ne contient pas encore de vraies données, supprimez la base dans Render puis relancez le Blueprint pour la recréer.

### Important sur l'offre gratuite de Render
- Le site gratuit **se met en veille** après 15 min sans visite : la première ouverture prend ~1 minute.
- La base PostgreSQL gratuite **expire après 30 jours**. Pour un usage réel, passez la base en offre payante (Basic) avant ce délai, et faites des sauvegardes régulières (Paramètres → Sauvegarde complète).

### Mettre à jour le logiciel
Modifiez les fichiers, puis `git add . && git commit -m "mise à jour" && git push` : Render redéploie automatiquement. Les données sont conservées.

### Mot de passe perdu
- Un utilisateur d'entreprise : réinitialisez-le depuis Plateforme → fiche de l'entreprise.
- Votre compte super-admin : Render → service → **Shell** :
```bash
flask --app app reset-admin NouveauMotDePasse2026
```

## 6. Rôles et droits (dans chaque entreprise)

| Action | Admin | Gestionnaire | Vendeur |
|---|:-:|:-:|:-:|
| Ventes, clients, encaissements | ✔ | ✔ | ✔ |
| Voir produits et stocks | ✔ | ✔ | ✔ |
| Créer/modifier produits, mouvements, inventaire | ✔ | ✔ | — |
| Achats, fournisseurs, annulation de ventes | ✔ | ✔ | — |
| Analyses et recommandations | ✔ | ✔ | — |
| Utilisateurs, paramètres, journal, sauvegarde, suppressions | ✔ | — | — |
