"""Configuration de ANSARTECH 224."""
import os
from datetime import timedelta

from dotenv import load_dotenv

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
load_dotenv(os.path.join(BASE_DIR, ".env"))


def _database_url():
    url = os.environ.get("DATABASE_URL", "").strip()
    if not url:
        return "sqlite:///" + os.path.join(BASE_DIR, "ansartech224.db")
    # Render fournit parfois "postgres://" : SQLAlchemy exige "postgresql://"
    if url.startswith("postgres://"):
        url = url.replace("postgres://", "postgresql://", 1)
    return url


class Config:
    APP_NAME = "ANSARTECH 224"
    SECRET_KEY = os.environ.get("SECRET_KEY") or "dev-cle-a-changer-en-production"
    SQLALCHEMY_DATABASE_URI = _database_url()
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True, "pool_recycle": 280}

    # Sécurité des sessions
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.environ.get("FLASK_ENV") == "production"
    REMEMBER_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SECURE = SESSION_COOKIE_SECURE
    PERMANENT_SESSION_LIFETIME = timedelta(hours=8)
    WTF_CSRF_TIME_LIMIT = None

    # Documents (stockés en base : le disque de Render est effacé à chaque déploiement)
    MAX_CONTENT_LENGTH = 6 * 1024 * 1024  # 6 Mo par requête
    MAX_DOCUMENT_SIZE = 5 * 1024 * 1024  # 5 Mo par fichier
    ALLOWED_EXTENSIONS = {"pdf", "png", "jpg", "jpeg", "gif", "webp", "doc", "docx",
                          "xls", "xlsx", "csv", "txt", "odt", "ods"}

    # Super-administrateur de la plateforme (vous), créé au premier démarrage
    ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME") or "admin"
    ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD") or "Admin@224"
    ADMIN_EMAIL = os.environ.get("ADMIN_EMAIL") or "admin@ansartech224.com"

    # Verrouillage après échecs de connexion
    MAX_LOGIN_ATTEMPTS = 5
    LOCKOUT_MINUTES = 15


class TestConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = "sqlite:///:memory:"
    SQLALCHEMY_ENGINE_OPTIONS = {}
    WTF_CSRF_ENABLED = False
    SESSION_COOKIE_SECURE = False
    ADMIN_USERNAME = "super"
    ADMIN_PASSWORD = "Super@224"
