/* ANSARTECH 224 — scripts de l'interface */
(function () {
  "use strict";

  // ---------- Menu mobile
  var toggle = document.getElementById("menuToggle");
  var overlay = document.getElementById("overlay");
  if (toggle) toggle.addEventListener("click", function () { document.body.classList.toggle("menu-open"); });
  if (overlay) overlay.addEventListener("click", function () { document.body.classList.remove("menu-open"); });

  // ---------- Fermeture des alertes
  document.addEventListener("click", function (e) {
    if (e.target.classList.contains("alert-close")) e.target.parentElement.remove();
  });

  // ---------- Confirmation avant action sensible
  document.addEventListener("submit", function (e) {
    var form = e.target;
    var message = form.getAttribute("data-confirm");
    if (message && !window.confirm(message)) { e.preventDefault(); return; }
    var btn = form.querySelector("button[type=submit], button:not([type])");
    if (btn && !form.hasAttribute("data-no-lock")) {
      setTimeout(function () { btn.disabled = true; }, 0); // évite les doubles envois
    }
  });

  // ---------- Formatage monétaire
  function fmt(n) {
    n = Math.round(Number(n) || 0);
    return n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  }
  function num(v) {
    var n = parseFloat(String(v || "").replace(/\s/g, "").replace(",", "."));
    return isNaN(n) ? 0 : n;
  }
  window.ansarFmt = fmt;

  // ---------- Éditeur de lignes (ventes et achats)
  var editor = document.querySelector("[data-line-editor]");
  if (!editor) return;

  var mode = editor.getAttribute("data-line-editor"); // "sale" ou "purchase"
  var searchUrl = editor.getAttribute("data-search-url");
  var currency = editor.getAttribute("data-currency") || "";
  var taxRate = num(editor.getAttribute("data-tax-rate"));
  var input = document.getElementById("productSearch");
  var results = document.getElementById("searchResults");
  var tbody = document.getElementById("lines");
  var emptyRow = document.getElementById("emptyLines");
  var timer = null;

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function recalc() {
    var subtotal = 0;
    var rows = tbody.querySelectorAll("tr.line");
    rows.forEach(function (row) {
      var q = num(row.querySelector(".q").value);
      var p = num(row.querySelector(".p").value);
      var total = q * p;
      subtotal += total;
      row.querySelector(".lt").textContent = fmt(total);
      var warn = row.querySelector(".stock-warn");
      if (warn) {
        var stock = num(row.getAttribute("data-stock"));
        warn.hidden = !(mode === "sale" && q > stock);
      }
    });
    if (emptyRow) emptyRow.hidden = rows.length > 0;
    var discountEl = document.getElementById("discount");
    var discount = discountEl ? num(discountEl.value) : 0;
    var base = Math.max(subtotal - discount, 0);
    var tax = mode === "sale" ? base * taxRate / 100 : 0;
    var total = base + tax;
    setText("subtotal", fmt(subtotal) + " " + currency);
    setText("taxAmount", fmt(tax) + " " + currency);
    setText("grandTotal", fmt(total) + " " + currency);
    var paid = document.getElementById("amount_paid");
    var changeEl = document.getElementById("changeInfo");
    if (paid && changeEl) {
      var p = paid.value.trim() === "" ? total : num(paid.value);
      if (p > total) changeEl.textContent = "Monnaie à rendre : " + fmt(p - total) + " " + currency;
      else if (p < total) changeEl.textContent = "Reste à payer : " + fmt(total - p) + " " + currency;
      else changeEl.textContent = "Paiement complet";
    }
  }
  function setText(id, text) { var el = document.getElementById(id); if (el) el.textContent = text; }

  function addLine(item) {
    var existing = tbody.querySelector('tr.line[data-id="' + item.id + '"]');
    if (existing) {
      var q = existing.querySelector(".q");
      q.value = num(q.value) + 1;
      recalc();
      return;
    }
    var price = item.price != null ? item.price : (mode === "sale" ? item.sale : item.cost);
    var tr = document.createElement("tr");
    tr.className = "line";
    tr.setAttribute("data-id", item.id);
    tr.setAttribute("data-stock", item.stock);
    tr.innerHTML =
      '<td class="product-cell"><input type="hidden" name="product_id[]" value="' + item.id + '">' +
      '<span class="cell-title">' + escapeHtml(item.name) + '</span>' +
      '<span class="cell-sub">' + escapeHtml(item.sku) + ' · stock : ' + fmt(item.stock) + ' ' + escapeHtml(item.unit || "") + '</span>' +
      '<span class="cell-sub stock-warn" style="color:#c62f2f" hidden>Stock insuffisant</span></td>' +
      '<td data-label="Quantité"><input class="q" type="number" name="quantity[]" min="0.001" step="any" inputmode="decimal" value="' + (item.qty || 1) + '" required></td>' +
      '<td data-label="Prix"><input class="p" type="number" name="price[]" min="0" step="any" inputmode="decimal" value="' + (price || 0) + '" required></td>' +
      '<td class="num lt" data-label="Total">0</td>' +
      '<td><button type="button" class="btn btn-ghost-danger btn-sm rm" aria-label="Retirer">✕</button></td>';
    tbody.appendChild(tr);
    recalc();
  }

  function search(q) {
    fetch(searchUrl + "?q=" + encodeURIComponent(q), { credentials: "same-origin" })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data.results.length) {
          results.innerHTML = '<div class="empty">Aucun produit trouvé</div>';
        } else {
          results.innerHTML = data.results.map(function (p) {
            var out = mode === "sale" && p.stock <= 0;
            return '<button type="button" data-item=\'' + escapeHtml(JSON.stringify({
              id: p.id, name: p.name, sku: p.sku, stock: p.stock, unit: p.unit,
              price: mode === "sale" ? p.price : p.cost })) + '\'' + (out ? " disabled" : "") + '>' +
              '<span><strong>' + escapeHtml(p.name) + '</strong><span class="cell-sub">' + escapeHtml(p.sku) +
              ' · stock ' + fmt(p.stock) + (out ? " (rupture)" : "") + '</span></span>' +
              '<span class="nowrap">' + fmt(mode === "sale" ? p.price : p.cost) + '</span></button>';
          }).join("");
        }
        results.hidden = false;
      })
      .catch(function () { results.innerHTML = '<div class="empty">Erreur de connexion</div>'; results.hidden = false; });
  }

  input.addEventListener("input", function () {
    clearTimeout(timer);
    var q = input.value.trim();
    timer = setTimeout(function () { search(q); }, 200);
  });
  input.addEventListener("focus", function () { search(input.value.trim()); });
  input.addEventListener("keydown", function (e) {
    if (e.key === "Enter") {
      e.preventDefault(); // lecteur code-barres : ajoute le premier résultat
      var first = results.querySelector("button:not([disabled])");
      if (first) first.click();
    }
  });
  results.addEventListener("click", function (e) {
    var btn = e.target.closest("button[data-item]");
    if (!btn) return;
    addLine(JSON.parse(btn.getAttribute("data-item")));
    results.hidden = true;
    input.value = "";
    input.focus();
  });
  document.addEventListener("click", function (e) {
    if (!e.target.closest(".search-box")) results.hidden = true;
  });
  tbody.addEventListener("input", recalc);
  tbody.addEventListener("click", function (e) {
    if (e.target.classList.contains("rm")) { e.target.closest("tr").remove(); recalc(); }
  });
  ["discount", "amount_paid"].forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.addEventListener("input", recalc);
  });

  editor.closest("form").addEventListener("submit", function (e) {
    if (!tbody.querySelector("tr.line")) {
      e.preventDefault();
      e.stopImmediatePropagation();
      alert("Ajoutez au moins un produit.");
      input.focus();
    }
  }, true);

  // lignes à restaurer après une erreur de validation
  try {
    JSON.parse(editor.getAttribute("data-initial") || "[]").forEach(addLine);
  } catch (err) { /* rien */ }
  recalc();
})();
