"""Multi-entreprises : isolation automatique des données de chaque entreprise.

Chaque requête de lecture, modification ou suppression sur une table d'entreprise
est automatiquement filtrée sur l'entreprise de l'utilisateur connecté, et chaque
nouvel enregistrement reçoit automatiquement son entreprise. Une entreprise ne peut
donc jamais voir ni modifier les données d'une autre, même en changeant un numéro
dans l'adresse de la page.
"""
from contextlib import contextmanager
from contextvars import ContextVar

from flask import g, has_request_context
from sqlalchemy import event
from sqlalchemy.orm import Session, with_loader_criteria

_forced_company = ContextVar("forced_company", default=None)


def current_company_id():
    forced = _forced_company.get()
    if forced is not None:
        return forced
    if has_request_context():
        return getattr(g, "company_id", None)
    return None


@contextmanager
def tenant_context(company_id):
    """Exécute un bloc de code au nom d'une entreprise (initialisation, tests, CLI)."""
    token = _forced_company.set(company_id)
    try:
        yield
    finally:
        _forced_company.reset(token)


_installed = False


def init_tenancy():
    global _installed
    if _installed:
        return
    _installed = True
    from .models import AuditLog, TenantMixin, User

    @event.listens_for(Session, "do_orm_execute")
    def _scope_to_company(state):
        if not (state.is_select or state.is_update or state.is_delete):
            return
        if state.execution_options.get("skip_tenant"):
            return
        company_id = current_company_id()
        if company_id is None:
            return
        state.statement = state.statement.options(
            with_loader_criteria(TenantMixin, lambda cls: cls.company_id == company_id, include_aliases=True),
            with_loader_criteria(User, lambda cls: cls.company_id == company_id, include_aliases=True),
            with_loader_criteria(AuditLog, lambda cls: cls.company_id == company_id, include_aliases=True),
        )

    @event.listens_for(Session, "before_flush")
    def _assign_company(session, _context, _instances):
        company_id = current_company_id()
        for obj in session.new:
            if isinstance(obj, TenantMixin) and obj.company_id is None:
                if company_id is None:
                    raise RuntimeError(f"Aucune entreprise active pour enregistrer {type(obj).__name__}")
                obj.company_id = company_id
            elif isinstance(obj, (User, AuditLog)) and obj.company_id is None and company_id is not None:
                if not (isinstance(obj, User) and obj.role == "superadmin"):
                    obj.company_id = company_id
