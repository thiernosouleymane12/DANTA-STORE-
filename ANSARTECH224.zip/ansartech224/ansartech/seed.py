"""Initialisation de la base et données de démonstration."""
import os
import random
from datetime import timedelta

from sqlalchemy.exc import IntegrityError, OperationalError, ProgrammingError

from .extensions import db
from .models import (Category, Company, Customer, Product, Purchase, PurchaseItem, Sale,
                     SaleItem, StockMovement, Supplier, User)
from .models import utcnow
from .tenancy import tenant_context

DEFAULT_CATEGORIES = ("Informatique", "Téléphonie", "Accessoires", "Électroménager", "Divers")


def init_database(app):
    try:
        db.create_all()
    except (OperationalError, ProgrammingError, IntegrityError):
        # Un autre processus vient de créer les tables : on continue
        db.session.rollback()

    try:
        if not User.query.filter_by(role="superadmin").first():
            owner = User(
                username=app.config["ADMIN_USERNAME"].lower(),
                full_name="Super-administrateur",
                email=app.config["ADMIN_EMAIL"],
                role="superadmin",
                company_id=None,
                must_change_password=not app.config.get("TESTING"),
            )
            owner.set_password(app.config["ADMIN_PASSWORD"])
            db.session.add(owner)
            db.session.commit()
    except IntegrityError:
        db.session.rollback()

    if os.environ.get("DEMO_DATA") == "1" and not Company.query.filter_by(code="demo").first():
        create_demo_company()


def unique_company_code(name):
    """Fabrique un code court et unique à partir du nom (ex. « boutique-kaloum »)."""
    import re
    import unicodedata
    text = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode().lower()
    base = re.sub(r"[^a-z0-9]+", "-", text).strip("-")[:24] or "entreprise"
    code, n = base, 2
    while Company.query.filter_by(code=code).first():
        code = f"{base}-{n}"
        n += 1
    return code


def create_company(name, admin_username, admin_password, admin_full_name="Administrateur",
                   must_change_password=True, **fields):
    """Crée une entreprise, ses catégories par défaut et son administrateur."""
    company = Company(name=name, code=fields.pop("code", None) or unique_company_code(name), **fields)
    db.session.add(company)
    db.session.flush()
    admin = User(username=admin_username.lower(), full_name=admin_full_name, role="admin",
                 company_id=company.id, must_change_password=must_change_password)
    admin.set_password(admin_password)
    db.session.add(admin)
    with tenant_context(company.id):
        for category in DEFAULT_CATEGORIES:
            db.session.add(Category(name=category, company_id=company.id))
        db.session.flush()
    return company, admin


def create_demo_company():
    """Entreprise de démonstration : identifiant demo / Demo@2026."""
    company, _ = create_company(
        "Boutique Démo Kaloum", "demo", "Demo@2026", "Gérant Démo", must_change_password=False,
        code="demo", activity="Informatique et téléphonie", address="Avenue de la République, Kaloum",
        phone="+224 620 00 00 00", email="demo@ansartech224.com")
    db.session.commit()
    load_demo_data(company.id)
    return company


def load_demo_data(company_id):
    """Remplit une entreprise avec des exemples réalistes (Conakry)."""
    with tenant_context(company_id):
        _load_demo_data()


def _load_demo_data():
    if Product.query.count() > 0:
        return
    admin = User.query.filter_by(role="admin").first()
    categories = {c.name: c for c in Category.query.all()}

    suppliers = [
        Supplier(name="Guinée Distribution SARL", contact="M. Camara", phone="+224 622 11 22 33",
                 address="Kaloum, Conakry"),
        Supplier(name="Madina Import-Export", contact="Mme Diallo", phone="+224 664 44 55 66",
                 address="Marché Madina, Conakry"),
        Supplier(name="Tech Africa Supply", contact="M. Bah", phone="+224 655 77 88 99",
                 email="ventes@techafrica.gn", address="Dixinn, Conakry"),
    ]
    db.session.add_all(suppliers)

    catalogue = [
        ("ORD-001", "Ordinateur portable HP 15", "Informatique", 4_500_000, 5_600_000, 8, 3),
        ("ORD-002", "Ordinateur portable Lenovo IdeaPad", "Informatique", 4_000_000, 5_000_000, 5, 3),
        ("IMP-001", "Imprimante Canon Pixma", "Informatique", 1_200_000, 1_550_000, 4, 2),
        ("TEL-001", "Smartphone Samsung Galaxy A15", "Téléphonie", 1_500_000, 1_900_000, 15, 5),
        ("TEL-002", "Smartphone Tecno Spark 20", "Téléphonie", 900_000, 1_150_000, 22, 6),
        ("TEL-003", "Téléphone Itel basique", "Téléphonie", 120_000, 175_000, 2, 10),
        ("ACC-001", "Chargeur rapide USB-C", "Accessoires", 45_000, 75_000, 60, 15),
        ("ACC-002", "Écouteurs Bluetooth", "Accessoires", 80_000, 130_000, 30, 10),
        ("ACC-003", "Clé USB 64 Go", "Accessoires", 60_000, 95_000, 0, 10),
        ("ACC-004", "Batterie externe 20000 mAh", "Accessoires", 150_000, 225_000, 12, 5),
        ("ELM-001", "Ventilateur sur pied", "Électroménager", 350_000, 475_000, 9, 4),
        ("ELM-002", "Régulateur de tension 2000VA", "Électroménager", 400_000, 560_000, 6, 3),
    ]
    products = []
    for sku, name, cat, cost, price, qty, min_qty in catalogue:
        product = Product(sku=sku, name=name, category=categories.get(cat), purchase_price=cost,
                          sale_price=price, quantity=qty, min_stock=min_qty)
        products.append(product)
        db.session.add(product)
    db.session.flush()

    for product in products:
        db.session.add(StockMovement(product=product, movement_type="entree", quantity=product.quantity,
                                     stock_after=product.quantity, reason="Stock initial", user=admin))

    customers = [
        Customer(name="Mamadou Sow", phone="+224 620 10 20 30", address="Ratoma"),
        Customer(name="Fatoumata Barry", phone="+224 657 40 50 60", address="Matam"),
        Customer(name="Entreprise BTP Kindia", phone="+224 628 70 80 90", address="Kindia"),
    ]
    db.session.add_all(customers)

    purchase = Purchase(reference="ACH-DEMO-00001", supplier=suppliers[2], status="recu",
                        user=admin, created_at=utcnow() - timedelta(days=40),
                        received_at=utcnow() - timedelta(days=38))
    purchase.items.append(PurchaseItem(product=products[0], quantity=5, unit_cost=4_500_000))
    purchase.items.append(PurchaseItem(product=products[3], quantity=10, unit_cost=1_500_000))
    purchase.total = sum(i.line_total for i in purchase.items)
    purchase.amount_paid = purchase.total
    db.session.add(purchase)

    rng = random.Random(224)
    sellable = [p for p in products if p.sku != "ACC-003"]
    for index in range(45):
        day = utcnow() - timedelta(days=rng.randint(0, 89), hours=rng.randint(0, 10))
        sale = Sale(invoice_number=f"FAC-DEMO-{index + 1:05d}",
                    customer=rng.choice(customers + [None, None]),
                    payment_method=rng.choice(["especes", "orange_money", "mtn_momo", "especes"]),
                    user=admin, created_at=day)
        for product in rng.sample(sellable, rng.randint(1, 3)):
            sale.items.append(SaleItem(product=product, quantity=rng.randint(1, 3),
                                       unit_price=product.sale_price, unit_cost=product.purchase_price))
        sale.subtotal = sum(i.line_total for i in sale.items)
        sale.total = sale.subtotal
        sale.amount_paid = sale.total
        sale.status = "payee"
        db.session.add(sale)
    db.session.commit()
