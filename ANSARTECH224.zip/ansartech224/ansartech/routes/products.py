"""Étape 5 — Gestion des produits et catégories."""
from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_login import login_required

from ..extensions import db
from ..models import Category, Product, SaleItem
from ..utils import audit, csv_response, move_stock, role_required, to_float, to_int

bp = Blueprint("products", __name__, url_prefix="/produits")


@bp.route("/")
@login_required
def index():
    q = request.args.get("q", "").strip()
    category_id = to_int(request.args.get("categorie"))
    status = request.args.get("statut", "")
    page = to_int(request.args.get("page"), 1) or 1

    query = Product.query.filter_by(is_active=(status != "archives"))
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Product.name.ilike(like), Product.sku.ilike(like),
                                    Product.barcode.ilike(like)))
    if category_id:
        query = query.filter(Product.category_id == category_id)
    if status == "bas":
        query = query.filter(Product.quantity <= Product.min_stock, Product.quantity > 0)
    elif status == "rupture":
        query = query.filter(Product.quantity <= 0)

    pagination = query.order_by(Product.name).paginate(page=page, per_page=25, error_out=False)
    return render_template("products/index.html", pagination=pagination, products=pagination.items,
                           categories=Category.query.order_by(Category.name).all(),
                           q=q, category_id=category_id, status=status)


@bp.route("/export")
@login_required
def export():
    rows = [(p.sku, p.name, p.category.name if p.category else "", p.unit, p.purchase_price,
             p.sale_price, p.quantity, p.min_stock, p.stock_value)
            for p in Product.query.filter_by(is_active=True).order_by(Product.name)]
    return csv_response("produits.csv", ["Code", "Nom", "Catégorie", "Unité", "Prix achat", "Prix vente",
                                         "Quantité", "Stock min", "Valeur stock"], rows)


@bp.route("/<int:product_id>")
@login_required
def detail(product_id):
    product = db.session.get(Product, product_id) or abort(404)
    from ..models import StockMovement
    movements = (StockMovement.query.filter_by(product_id=product.id)
                 .order_by(StockMovement.created_at.desc()).limit(20).all())
    return render_template("products/detail.html", product=product, movements=movements)


@bp.route("/nouveau", methods=["GET", "POST"])
@bp.route("/<int:product_id>/modifier", methods=["GET", "POST"])
@role_required("gestionnaire")
def form(product_id=None):
    product = db.session.get(Product, product_id) if product_id else None
    if product_id and not product:
        abort(404)
    categories = Category.query.order_by(Category.name).all()

    if request.method == "POST":
        f = request.form
        sku = f.get("sku", "").strip().upper()
        name = f.get("name", "").strip()
        purchase_price = to_float(f.get("purchase_price"))
        sale_price = to_float(f.get("sale_price"))
        min_stock = to_float(f.get("min_stock"), 0)
        initial_qty = to_float(f.get("quantity"), 0)
        errors = []
        if not sku:
            errors.append("Le code produit est obligatoire.")
        if not name:
            errors.append("Le nom du produit est obligatoire.")
        if purchase_price < 0 or sale_price < 0 or min_stock < 0 or initial_qty < 0:
            errors.append("Les prix et quantités ne peuvent pas être négatifs.")
        duplicate = Product.query.filter(Product.sku == sku).first()
        if duplicate and (not product or duplicate.id != product.id):
            errors.append("Ce code produit existe déjà.")
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("products/form.html", product=product, categories=categories, form=f)
        if sale_price < purchase_price:
            flash("Attention : le prix de vente est inférieur au prix d'achat.", "warning")

        creating = product is None
        if creating:
            product = Product(quantity=0)
            db.session.add(product)
        product.sku = sku[:40]
        product.name = name[:150]
        product.barcode = f.get("barcode", "").strip()[:60]
        product.description = f.get("description", "").strip()
        product.unit = f.get("unit", "pièce").strip()[:20] or "pièce"
        product.category_id = to_int(f.get("category_id"))
        product.purchase_price = purchase_price
        product.sale_price = sale_price
        product.min_stock = min_stock
        db.session.flush()
        if creating and initial_qty > 0:
            move_stock(product, initial_qty, "entree", "Stock initial")
        audit("creation_produit" if creating else "modification_produit", f"{sku} - {name}")
        db.session.commit()
        flash("Produit enregistré.", "success")
        return redirect(url_for("products.detail", product_id=product.id))

    return render_template("products/form.html", product=product, categories=categories, form={})


@bp.route("/<int:product_id>/archiver", methods=["POST"])
@role_required("gestionnaire")
def toggle_archive(product_id):
    product = db.session.get(Product, product_id) or abort(404)
    product.is_active = not product.is_active
    audit("archivage_produit", f"{product.sku} actif={product.is_active}")
    db.session.commit()
    flash("Produit archivé." if not product.is_active else "Produit réactivé.", "success")
    return redirect(url_for("products.detail", product_id=product.id))


@bp.route("/<int:product_id>/supprimer", methods=["POST"])
@role_required("admin")
def delete(product_id):
    product = db.session.get(Product, product_id) or abort(404)
    from ..models import PurchaseItem, StockMovement
    used = (SaleItem.query.filter_by(product_id=product.id).first()
            or PurchaseItem.query.filter_by(product_id=product.id).first())
    if used:
        flash("Ce produit figure dans des ventes ou achats : archivez-le plutôt que de le supprimer.", "warning")
        return redirect(url_for("products.detail", product_id=product.id))
    StockMovement.query.filter_by(product_id=product.id).delete()
    audit("suppression_produit", f"{product.sku} - {product.name}")
    db.session.delete(product)
    db.session.commit()
    flash("Produit supprimé.", "success")
    return redirect(url_for("products.index"))


# ---------------------------------------------------------------- Catégories
@bp.route("/categories", methods=["GET", "POST"])
@role_required("gestionnaire")
def categories():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Le nom de la catégorie est obligatoire.", "danger")
        elif Category.query.filter(db.func.lower(Category.name) == name.lower()).first():
            flash("Cette catégorie existe déjà.", "danger")
        else:
            db.session.add(Category(name=name[:80]))
            db.session.commit()
            flash("Catégorie ajoutée.", "success")
        return redirect(url_for("products.categories"))
    rows = Category.query.order_by(Category.name).all()
    return render_template("products/categories.html", categories=rows)


@bp.route("/categories/<int:category_id>/supprimer", methods=["POST"])
@role_required("gestionnaire")
def delete_category(category_id):
    category = db.session.get(Category, category_id) or abort(404)
    if category.products:
        flash("Impossible : des produits utilisent cette catégorie.", "danger")
    else:
        db.session.delete(category)
        db.session.commit()
        flash("Catégorie supprimée.", "success")
    return redirect(url_for("products.categories"))


@bp.route("/api/recherche")
@login_required
def api_search():
    """Recherche rapide utilisée par le formulaire de vente et d'achat."""
    q = request.args.get("q", "").strip()
    query = Product.query.filter_by(is_active=True)
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Product.name.ilike(like), Product.sku.ilike(like),
                                    Product.barcode == q))
    return {"results": [
        {"id": p.id, "sku": p.sku, "name": p.name, "price": p.sale_price,
         "cost": p.purchase_price, "stock": p.quantity, "unit": p.unit}
        for p in query.order_by(Product.name).limit(20)
    ]}
