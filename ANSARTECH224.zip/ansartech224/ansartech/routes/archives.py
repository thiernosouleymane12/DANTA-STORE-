"""Étape 10 — Archives, documents et échanges internes."""
import io
import mimetypes

from flask import (Blueprint, abort, current_app, flash, redirect, render_template,
                   request, send_file, url_for)
from flask_login import current_user, login_required
from werkzeug.utils import secure_filename

from ..extensions import db
from ..models import DOC_CATEGORIES, Document, Message, User
from ..utils import audit, role_required, to_int

bp = Blueprint("archives", __name__, url_prefix="/archives")


def _allowed(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in current_app.config["ALLOWED_EXTENSIONS"]


# ---------------------------------------------------------------- Documents
@bp.route("/")
@login_required
def documents():
    q = request.args.get("q", "").strip()
    category = request.args.get("categorie", "")
    query = Document.query.with_entities(
        Document.id, Document.title, Document.category, Document.original_name, Document.size,
        Document.created_at, Document.uploaded_by)
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Document.title.ilike(like), Document.original_name.ilike(like),
                                    Document.description.ilike(like)))
    if category in DOC_CATEGORIES:
        query = query.filter(Document.category == category)
    rows = query.order_by(Document.created_at.desc()).limit(300).all()
    users = {u.id: u.full_name for u in User.query.all()}
    return render_template("archives/documents.html", documents=rows, users=users,
                           categories=DOC_CATEGORIES, q=q, category=category)


@bp.route("/ajouter", methods=["POST"])
@login_required
def upload():
    file = request.files.get("file")
    title = request.form.get("title", "").strip()
    category = request.form.get("category", "autre")
    if not file or not file.filename:
        flash("Choisissez un fichier.", "danger")
        return redirect(url_for("archives.documents"))
    filename = secure_filename(file.filename) or "document"
    if not _allowed(file.filename):
        flash("Type de fichier non autorisé (PDF, images, Word, Excel, CSV, texte).", "danger")
        return redirect(url_for("archives.documents"))
    data = file.read()
    if len(data) > current_app.config["MAX_DOCUMENT_SIZE"]:
        flash("Fichier trop volumineux (5 Mo maximum).", "danger")
        return redirect(url_for("archives.documents"))
    if not data:
        flash("Le fichier est vide.", "danger")
        return redirect(url_for("archives.documents"))
    doc = Document(title=(title or file.filename)[:200],
                   category=category if category in DOC_CATEGORIES else "autre",
                   description=request.form.get("description", "").strip(),
                   original_name=file.filename[:255],
                   mimetype=mimetypes.guess_type(filename)[0] or "application/octet-stream",
                   size=len(data), data=data, uploaded_by=current_user.id)
    db.session.add(doc)
    audit("ajout_document", doc.title)
    db.session.commit()
    flash("Document archivé.", "success")
    return redirect(url_for("archives.documents"))


@bp.route("/<int:doc_id>/telecharger")
@login_required
def download(doc_id):
    doc = db.session.get(Document, doc_id) or abort(404)
    inline = request.args.get("voir") == "1" and (doc.mimetype or "").startswith(("image/", "application/pdf"))
    return send_file(io.BytesIO(doc.data), mimetype=doc.mimetype, as_attachment=not inline,
                     download_name=secure_filename(doc.original_name) or "document")


@bp.route("/<int:doc_id>/supprimer", methods=["POST"])
@login_required
def delete(doc_id):
    doc = db.session.get(Document, doc_id) or abort(404)
    if current_user.effective_role not in ("admin", "gestionnaire") and doc.uploaded_by != current_user.id:
        abort(403)
    audit("suppression_document", doc.title)
    db.session.delete(doc)
    db.session.commit()
    flash("Document supprimé.", "success")
    return redirect(url_for("archives.documents"))


# ---------------------------------------------------------------- Messagerie interne
def _inbox_query():
    return Message.query.filter(
        db.or_(Message.recipient_id == current_user.id, Message.recipient_id.is_(None)),
        Message.sender_id != current_user.id)


@bp.route("/messages")
@login_required
def messages():
    box = request.args.get("boite", "recus")
    if box == "envoyes":
        rows = Message.query.filter_by(sender_id=current_user.id)
    else:
        rows = _inbox_query()
    rows = rows.order_by(Message.created_at.desc()).limit(200).all()
    return render_template("archives/messages.html", messages=rows, box=box)


@bp.route("/messages/nouveau", methods=["GET", "POST"])
@login_required
def compose():
    users = User.query.filter(User.id != current_user.id, User.is_active_account.is_(True)) \
        .order_by(User.full_name).all()
    if request.method == "POST":
        subject = request.form.get("subject", "").strip()
        body = request.form.get("body", "").strip()
        recipient_raw = request.form.get("recipient_id", "")
        recipient_id = None if recipient_raw == "all" else to_int(recipient_raw)
        errors = []
        if not subject or not body:
            errors.append("Le sujet et le message sont obligatoires.")
        if recipient_raw != "all" and not db.session.get(User, recipient_id or 0):
            errors.append("Choisissez un destinataire.")
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("archives/compose.html", users=users, form=request.form)
        db.session.add(Message(sender_id=current_user.id, recipient_id=recipient_id,
                               subject=subject[:200], body=body))
        db.session.commit()
        flash("Message envoyé.", "success")
        return redirect(url_for("archives.messages", boite="envoyes"))
    form = {}
    reply = db.session.get(Message, to_int(request.args.get("repondre"), 0) or 0)
    if reply and (reply.recipient_id in (None, current_user.id)):
        form = {"recipient_id": str(reply.sender_id), "subject": "RE : " + reply.subject}
    return render_template("archives/compose.html", users=users, form=form)


@bp.route("/messages/<int:message_id>")
@login_required
def message_detail(message_id):
    message = db.session.get(Message, message_id) or abort(404)
    if message.sender_id != current_user.id and message.recipient_id not in (None, current_user.id):
        abort(403)
    if message.recipient_id == current_user.id and not message.is_read:
        message.is_read = True
        db.session.commit()
    return render_template("archives/message_detail.html", message=message)


@bp.route("/messages/tout-lu", methods=["POST"])
@login_required
def mark_all_read():
    for message in _inbox_query().filter(Message.is_read.is_(False)):
        if message.recipient_id == current_user.id:
            message.is_read = True
    db.session.commit()
    return redirect(url_for("archives.messages"))


@bp.route("/messages/<int:message_id>/supprimer", methods=["POST"])
@role_required("admin")
def delete_message(message_id):
    message = db.session.get(Message, message_id) or abort(404)
    db.session.delete(message)
    db.session.commit()
    flash("Message supprimé.", "success")
    return redirect(url_for("archives.messages"))
