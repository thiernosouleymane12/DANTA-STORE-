"""Étape 3 — Connexion et gestion des utilisateurs."""
import re
from datetime import timedelta
from urllib.parse import urlparse

from flask import (Blueprint, abort, current_app, flash, g, redirect, render_template,
                   request, session, url_for)
from flask_login import current_user, login_required, login_user, logout_user

from ..extensions import db
from ..models import TENANT_ROLES, Company, User
from ..utils import audit, role_required
from ..models import utcnow

bp = Blueprint("auth", __name__)


def password_errors(password):
    errors = []
    if len(password) < 8:
        errors.append("Le mot de passe doit contenir au moins 8 caractères.")
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        errors.append("Le mot de passe doit contenir des lettres et des chiffres.")
    return errors


def _safe_next(target):
    if not target:
        return None
    parsed = urlparse(target)
    if parsed.netloc or parsed.scheme or not target.startswith("/") or target.startswith("//"):
        return None
    return target


@bp.route("/connexion", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("dashboard.index"))
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "")
        user = User.query.filter(db.func.lower(User.username) == username).first()
        error = "Identifiant ou mot de passe incorrect."

        if user and user.locked_until and user.locked_until > utcnow():
            minutes = int((user.locked_until - utcnow()).total_seconds() // 60) + 1
            flash(f"Compte temporairement bloqué. Réessayez dans {minutes} minute(s).", "danger")
            return render_template("auth/login.html", username=username)

        if user and user.check_password(password):
            if not user.is_active_account:
                flash("Ce compte est désactivé. Contactez l'administrateur.", "danger")
                return render_template("auth/login.html", username=username)
            if user.role != "superadmin":
                company = db.session.get(Company, user.company_id) if user.company_id else None
                if company is None or not company.can_login:
                    reason = "expiré" if company is not None and company.is_expired else "suspendu"
                    flash(f"L'abonnement de votre entreprise est {reason}. Contactez ANSARTECH 224.", "danger")
                    return render_template("auth/login.html", username=username)
            user.failed_attempts = 0
            user.locked_until = None
            user.last_login = utcnow()
            login_user(user, remember=bool(request.form.get("remember")))
            session.pop("support_company_id", None)
            audit("connexion", f"Connexion de {user.username}", company_id=user.company_id)
            db.session.commit()
            home = url_for("platform.index") if user.role == "superadmin" else url_for("dashboard.index")
            return redirect(_safe_next(request.args.get("next")) or home)

        if user:
            user.failed_attempts = (user.failed_attempts or 0) + 1
            if user.failed_attempts >= current_app.config["MAX_LOGIN_ATTEMPTS"]:
                user.locked_until = utcnow() + timedelta(
                    minutes=current_app.config["LOCKOUT_MINUTES"])
                user.failed_attempts = 0
                error = (f"Trop d'essais. Compte bloqué {current_app.config['LOCKOUT_MINUTES']} minutes.")
            audit("echec_connexion", f"Échec pour {username}", company_id=user.company_id)
            db.session.commit()
        flash(error, "danger")
        return render_template("auth/login.html", username=username)
    return render_template("auth/login.html")


@bp.route("/deconnexion", methods=["POST"])
@login_required
def logout():
    audit("deconnexion", current_user.username)
    db.session.commit()
    session.pop("support_company_id", None)
    logout_user()
    flash("Vous êtes déconnecté.", "info")
    return redirect(url_for("auth.login"))


@bp.route("/mot-de-passe", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        confirm = request.form.get("confirm_password", "")
        errors = []
        if not current_user.check_password(current):
            errors.append("Le mot de passe actuel est incorrect.")
        if new != confirm:
            errors.append("Les deux nouveaux mots de passe ne correspondent pas.")
        if new == current:
            errors.append("Le nouveau mot de passe doit être différent de l'ancien.")
        errors += password_errors(new)
        if errors:
            for e in errors:
                flash(e, "danger")
        else:
            current_user.set_password(new)
            current_user.must_change_password = False
            audit("changement_mot_de_passe", current_user.username)
            db.session.commit()
            flash("Mot de passe modifié avec succès.", "success")
            return redirect(url_for("dashboard.index"))
    return render_template("auth/change_password.html")


@bp.route("/profil", methods=["GET", "POST"])
@login_required
def profile():
    if request.method == "POST":
        full_name = request.form.get("full_name", "").strip()
        if not full_name:
            flash("Le nom complet est obligatoire.", "danger")
        else:
            current_user.full_name = full_name[:120]
            current_user.email = request.form.get("email", "").strip()[:120]
            current_user.phone = request.form.get("phone", "").strip()[:30]
            db.session.commit()
            flash("Profil mis à jour.", "success")
            return redirect(url_for("auth.profile"))
    return render_template("auth/profile.html")


# ---------------------------------------------------------------- Utilisateurs (admin)
def _company_or_platform():
    """La gestion des utilisateurs se fait toujours dans le cadre d'une entreprise."""
    if not g.get("company_id"):
        return redirect(url_for("platform.index"))
    return None


@bp.route("/utilisateurs")
@role_required("admin")
def users():
    redirect_response = _company_or_platform()
    if redirect_response:
        return redirect_response
    company = db.session.get(Company, g.company_id)
    rows = User.query.filter(User.company_id == g.company_id).order_by(User.full_name).all()
    return render_template("auth/users.html", users=rows, roles=TENANT_ROLES, company=company)


@bp.route("/utilisateurs/nouveau", methods=["GET", "POST"])
@bp.route("/utilisateurs/<int:user_id>/modifier", methods=["GET", "POST"])
@role_required("admin")
def user_form(user_id=None):
    redirect_response = _company_or_platform()
    if redirect_response:
        return redirect_response
    user = db.session.get(User, user_id) if user_id else None
    if user_id and (not user or user.company_id != g.company_id):
        abort(404)
    company = db.session.get(Company, g.company_id)
    if request.method == "POST":
        username = request.form.get("username", "").strip().lower()
        full_name = request.form.get("full_name", "").strip()
        role = request.form.get("role", "vendeur")
        password = request.form.get("password", "")
        errors = []
        if not re.fullmatch(r"[a-z0-9._-]{3,50}", username):
            errors.append("Identifiant : 3 à 50 caractères (lettres minuscules, chiffres, . _ -).")
        if not full_name:
            errors.append("Le nom complet est obligatoire.")
        if role not in TENANT_ROLES:
            errors.append("Rôle invalide.")
        # identifiant unique sur toute la plateforme
        existing = User.query.execution_options(skip_tenant=True).filter(
            db.func.lower(User.username) == username).first()
        if existing and (not user or existing.id != user.id):
            errors.append("Cet identifiant est déjà utilisé.")
        if not user or password:
            errors += password_errors(password)
        if user and user.id == current_user.id and role != "admin":
            errors.append("Vous ne pouvez pas retirer votre propre rôle administrateur.")
        if not user and User.query.filter(User.company_id == g.company_id).count() >= company.max_users:
            errors.append(f"Limite atteinte : votre abonnement permet {company.max_users} utilisateur(s).")
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("auth/user_form.html", user=user, roles=TENANT_ROLES, form=request.form)

        creating = user is None
        if creating:
            user = User(must_change_password=True, company_id=g.company_id)
            db.session.add(user)
        user.username = username
        user.full_name = full_name[:120]
        user.email = request.form.get("email", "").strip()[:120]
        user.phone = request.form.get("phone", "").strip()[:30]
        user.role = role
        if password:
            user.set_password(password)
            if not creating:
                user.must_change_password = True
        audit("creation_utilisateur" if creating else "modification_utilisateur", username)
        db.session.commit()
        flash("Utilisateur enregistré.", "success")
        return redirect(url_for("auth.users"))
    return render_template("auth/user_form.html", user=user, roles=TENANT_ROLES, form={})


@bp.route("/utilisateurs/<int:user_id>/statut", methods=["POST"])
@role_required("admin")
def toggle_user(user_id):
    redirect_response = _company_or_platform()
    if redirect_response:
        return redirect_response
    user = db.session.get(User, user_id)
    if not user or user.company_id != g.company_id:
        abort(404)
    if user.id == current_user.id:
        flash("Vous ne pouvez pas désactiver votre propre compte.", "danger")
    else:
        user.is_active_account = not user.is_active_account
        user.failed_attempts = 0
        user.locked_until = None
        audit("statut_utilisateur", f"{user.username} -> {'actif' if user.is_active_account else 'inactif'}")
        db.session.commit()
        flash("Statut du compte modifié.", "success")
    return redirect(url_for("auth.users"))
