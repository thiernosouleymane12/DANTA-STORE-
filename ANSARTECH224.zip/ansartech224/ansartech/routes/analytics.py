"""Étape 9 — Analyses et recommandations."""
import math
from collections import defaultdict
from datetime import timedelta

from flask import Blueprint, render_template, request

from ..models import PAYMENT_METHODS, Product, Sale
from ..utils import csv_response, money, role_required, to_int
from ..models import utcnow

bp = Blueprint("analytics", __name__, url_prefix="/analyses")

DAYS_FR = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
MONTHS_FR = ["Janv", "Févr", "Mars", "Avr", "Mai", "Juin", "Juil", "Août", "Sept", "Oct", "Nov", "Déc"]


def build_analysis(days):
    now = utcnow()
    start = now - timedelta(days=days)
    sales = Sale.query.filter(Sale.status != "annulee", Sale.created_at >= start).all()
    products = Product.query.filter_by(is_active=True).all()

    revenue = sum(s.total for s in sales)
    profit = sum(s.profit for s in sales)
    summary = {
        "revenue": revenue,
        "profit": profit,
        "margin": (profit / revenue * 100) if revenue else 0,
        "count": len(sales),
        "basket": revenue / len(sales) if sales else 0,
        "receivables": sum(s.balance for s in Sale.query.filter(Sale.status.in_(["partielle", "impayee"]))),
    }

    per_product = defaultdict(lambda: {"qty": 0, "revenue": 0, "profit": 0, "last": None})
    by_category = defaultdict(float)
    by_payment = defaultdict(float)
    by_weekday = [0.0] * 7
    for sale in sales:
        by_payment[PAYMENT_METHODS.get(sale.payment_method, sale.payment_method)] += sale.total
        by_weekday[sale.created_at.weekday()] += sale.total
        for item in sale.items:
            row = per_product[item.product_id]
            row["qty"] += item.quantity
            row["revenue"] += item.line_total
            row["profit"] += item.quantity * (item.unit_price - item.unit_cost)
            if row["last"] is None or sale.created_at > row["last"]:
                row["last"] = sale.created_at
            category = item.product.category.name if item.product.category else "Sans catégorie"
            by_category[category] += item.line_total

    product_map = {p.id: p for p in Product.query.all()}
    top = sorted(per_product.items(), key=lambda kv: kv[1]["revenue"], reverse=True)[:10]
    top_products = [{"product": product_map[pid], **data} for pid, data in top if pid in product_map]

    # 12 derniers mois
    months = []
    cursor = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    for _ in range(12):
        months.append(cursor)
        cursor = (cursor - timedelta(days=1)).replace(day=1)
    months.reverse()
    year_sales = Sale.query.filter(Sale.status != "annulee", Sale.created_at >= months[0]).all()
    monthly_rev = defaultdict(float)
    monthly_profit = defaultdict(float)
    for sale in year_sales:
        key = (sale.created_at.year, sale.created_at.month)
        monthly_rev[key] += sale.total
        monthly_profit[key] += sale.profit
    chart = {
        "labels": [f"{MONTHS_FR[m.month - 1]} {str(m.year)[2:]}" for m in months],
        "revenue": [round(monthly_rev[(m.year, m.month)]) for m in months],
        "profit": [round(monthly_profit[(m.year, m.month)]) for m in months],
        "categories": {k: round(v) for k, v in sorted(by_category.items(), key=lambda kv: -kv[1])},
        "payments": {k: round(v) for k, v in sorted(by_payment.items(), key=lambda kv: -kv[1])},
        "weekdays": {"labels": DAYS_FR, "data": [round(v) for v in by_weekday]},
    }

    recommendations = _recommendations(products, per_product, days, summary, by_weekday)
    return summary, top_products, chart, recommendations


def _recommendations(products, per_product, days, summary, by_weekday):
    reorder, dormant, low_margin = [], [], []
    for product in products:
        sold = per_product.get(product.id, {}).get("qty", 0)
        daily = sold / days if days else 0
        cover = product.quantity / daily if daily > 0 else None
        if product.quantity <= product.min_stock or (cover is not None and cover < 14):
            target = max(daily * 30, product.min_stock * 2)
            qty = math.ceil(max(target - product.quantity, 0))
            if qty > 0:
                reorder.append({"product": product, "daily": daily, "cover": cover, "qty": qty,
                                "cost": qty * product.purchase_price,
                                "urgent": product.quantity <= 0 or (cover is not None and cover < 7)})
        if product.quantity > 0 and sold == 0:
            dormant.append(product)
        if product.sale_price > 0 and product.margin_rate < 10:
            low_margin.append(product)

    reorder.sort(key=lambda r: (not r["urgent"], r["cover"] if r["cover"] is not None else 0))
    dormant.sort(key=lambda p: -p.stock_value)

    advice = []
    urgent = [r for r in reorder if r["urgent"]]
    if urgent:
        advice.append(("danger", f"{len(urgent)} produit(s) en rupture ou à moins de 7 jours de stock : "
                                 "passez commande en priorité."))
    if dormant:
        value = sum(p.stock_value for p in dormant)
        advice.append(("warning", f"{len(dormant)} produit(s) sans vente sur la période immobilisent "
                                  f"{money(value)} : envisagez une promotion ou un déstockage."))
    if low_margin:
        advice.append(("warning", f"{len(low_margin)} produit(s) ont une marge inférieure à 10 % : "
                                  "révisez leur prix de vente ou négociez le prix d'achat."))
    if summary["receivables"] > 0:
        advice.append(("info", f"{money(summary['receivables'])} restent à encaisser auprès des clients : "
                               "relancez les factures impayées."))
    if any(by_weekday):
        best = max(range(7), key=lambda i: by_weekday[i])
        advice.append(("success", f"Le {DAYS_FR[best].lower()} est votre meilleur jour de vente : "
                                  "renforcez le personnel et le stock ce jour-là."))
    if summary["count"] and summary["margin"] < 15:
        advice.append(("warning", f"Marge moyenne de {summary['margin']:.1f} % : surveillez vos remises."))
    if not advice:
        advice.append(("success", "Aucune alerte : votre activité est saine sur cette période."))
    return {"reorder": reorder, "dormant": dormant[:15], "low_margin": low_margin[:15], "advice": advice}


def _period():
    days = to_int(request.args.get("jours"), 30)
    return days if days in (7, 30, 90, 180, 365) else 30


@bp.route("/")
@role_required("gestionnaire")
def index():
    days = _period()
    summary, top_products, chart, recommendations = build_analysis(days)
    return render_template("analytics/index.html", days=days, summary=summary, top_products=top_products,
                           chart=chart, rec=recommendations)


@bp.route("/commande-suggeree.csv")
@role_required("gestionnaire")
def export_reorder():
    _, _, _, rec = build_analysis(_period())
    rows = [(r["product"].sku, r["product"].name, r["product"].quantity, round(r["daily"], 2),
             round(r["cover"]) if r["cover"] is not None else "", r["qty"], r["cost"],
             "Oui" if r["urgent"] else "Non") for r in rec["reorder"]]
    return csv_response("commande_suggeree.csv", ["Code", "Produit", "Stock", "Ventes/jour",
                                                  "Jours de stock", "Qté à commander", "Coût estimé",
                                                  "Urgent"], rows)
