"""Espace Plateforme : le propriétaire d'ANSARTECH 224 gère ses entreprises clientes."""
import re
from datetime import date, timedelta

from flask import Blueprint, abort, flash, redirect, render_template, request, session, url_for

from ..extensions import db
from ..models import AuditLog, Company, Product, Sale, User
from ..models import utcnow
from ..seed import create_company
from ..utils import audit, superadmin_required, to_int

bp = Blueprint("platform", __name__, url_prefix="/plateforme")

COMPANY_TEXT_FIELDS = {
    "name": 150, "activity": 150, "address": 255, "city": 80, "country": 80, "phone": 60,
    "email": 120, "website": 150, "rccm": 80, "nif": 80, "contact_name": 120,
}


def _password_errors(password):
    from .auth import password_errors
    return password_errors(password)


def _parse_date(value):
    try:
        return date.fromisoformat(value) if value else None
    except ValueError:
        return False


def _company_stats(company):
    since = utcnow() - timedelta(days=30)
    sales = Sale.query.filter(Sale.company_id == company.id, Sale.status != "annulee",
                              Sale.created_at >= since)
    revenue = sales.with_entities(db.func.coalesce(db.func.sum(Sale.total), 0)).scalar() or 0
    last = (AuditLog.query.filter(AuditLog.company_id == company.id)
            .order_by(AuditLog.created_at.desc()).first())
    return {
        "users": User.query.filter_by(company_id=company.id).count(),
        "products": Product.query.filter_by(company_id=company.id).count(),
        "sales_30": sales.count(),
        "revenue_30": revenue,
        "last_activity": last.created_at if last else None,
    }


@bp.route("/")
@superadmin_required
def index():
    q = request.args.get("q", "").strip()
    status = request.args.get("statut", "")
    query = Company.query
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Company.name.ilike(like), Company.code.ilike(like),
                                    Company.phone.ilike(like), Company.city.ilike(like)))
    companies = query.order_by(Company.name).all()
    today = utcnow().date()
    if status == "actives":
        companies = [c for c in companies if c.can_login]
    elif status == "suspendues":
        companies = [c for c in companies if not c.is_active]
    elif status == "expirees":
        companies = [c for c in companies if c.is_expired]
    elif status == "bientot":
        companies = [c for c in companies if c.subscription_end and today <= c.subscription_end <= today + timedelta(days=15)]
    stats = {c.id: _company_stats(c) for c in companies}
    all_companies = Company.query.all()
    totals = {
        "companies": len(all_companies),
        "active": sum(1 for c in all_companies if c.can_login),
        "expiring": sum(1 for c in all_companies if c.subscription_end
                        and today <= c.subscription_end <= today + timedelta(days=15)),
        "users": User.query.filter(User.company_id.isnot(None)).count(),
    }
    return render_template("platform/index.html", companies=companies, stats=stats, totals=totals,
                           q=q, status=status, today=today)


def _read_company_form(form, company=None):
    errors, values = [], {}
    for field, size in COMPANY_TEXT_FIELDS.items():
        values[field] = form.get(field, "").strip()[:size]
    if not values["name"]:
        errors.append("Le nom de l'entreprise est obligatoire.")
    code = form.get("code", "").strip().lower()
    if code:
        if not re.fullmatch(r"[a-z0-9-]{2,30}", code):
            errors.append("Code : 2 à 30 caractères (lettres minuscules, chiffres, tirets).")
        other = Company.query.filter_by(code=code).first()
        if other and (company is None or other.id != company.id):
            errors.append("Ce code d'entreprise est déjà utilisé.")
        values["code"] = code
    end = _parse_date(form.get("subscription_end", ""))
    if end is False:
        errors.append("Date de fin d'abonnement invalide.")
    values["subscription_end"] = end or None
    max_users = to_int(form.get("max_users"), 0)
    if not max_users or max_users < 1 or max_users > 500:
        errors.append("Nombre d'utilisateurs autorisés : entre 1 et 500.")
    values["max_users"] = max_users or 1
    values["notes"] = form.get("notes", "").strip()
    return values, errors


@bp.route("/entreprises/nouvelle", methods=["GET", "POST"])
@superadmin_required
def company_new():
    if request.method == "POST":
        values, errors = _read_company_form(request.form)
        username = request.form.get("admin_username", "").strip().lower()
        password = request.form.get("admin_password", "")
        admin_name = request.form.get("admin_full_name", "").strip() or "Administrateur"
        if not re.fullmatch(r"[a-z0-9._-]{3,50}", username):
            errors.append("Identifiant de l'administrateur : 3 à 50 caractères (lettres minuscules, chiffres, . _ -).")
        elif User.query.filter(db.func.lower(User.username) == username).first():
            errors.append("Cet identifiant est déjà utilisé sur la plateforme.")
        errors += _password_errors(password)
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("platform/company_form.html", company=None, form=request.form)
        name = values.pop("name")
        company, _admin = create_company(name, username, password, admin_name[:120], **values)
        audit("creation_entreprise", f"{company.name} ({company.code}) admin={username}", company_id=company.id)
        db.session.commit()
        flash(f"Entreprise « {company.name} » créée. Identifiant administrateur : {username} "
              "(mot de passe à changer à la 1re connexion).", "success")
        return redirect(url_for("platform.company_detail", company_id=company.id))
    default_end = (utcnow().date() + timedelta(days=30)).isoformat()
    return render_template("platform/company_form.html", company=None,
                           form={"subscription_end": default_end, "max_users": "5",
                                 "city": "Conakry", "country": "Guinée"})


@bp.route("/entreprises/<int:company_id>")
@superadmin_required
def company_detail(company_id):
    company = db.session.get(Company, company_id) or abort(404)
    users = User.query.filter_by(company_id=company.id).order_by(User.role, User.full_name).all()
    logs = (AuditLog.query.filter_by(company_id=company.id).order_by(AuditLog.created_at.desc()).limit(15).all())
    return render_template("platform/company_detail.html", company=company, users=users,
                           stats=_company_stats(company), logs=logs)


@bp.route("/entreprises/<int:company_id>/modifier", methods=["GET", "POST"])
@superadmin_required
def company_edit(company_id):
    company = db.session.get(Company, company_id) or abort(404)
    if request.method == "POST":
        values, errors = _read_company_form(request.form, company)
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("platform/company_form.html", company=company, form=request.form)
        for key, value in values.items():
            setattr(company, key, value)
        audit("modification_entreprise", company.name, company_id=company.id)
        db.session.commit()
        flash("Entreprise mise à jour.", "success")
        return redirect(url_for("platform.company_detail", company_id=company.id))
    form = {field: getattr(company, field) or "" for field in COMPANY_TEXT_FIELDS}
    form.update(code=company.code, max_users=company.max_users, notes=company.notes or "",
                subscription_end=company.subscription_end.isoformat() if company.subscription_end else "")
    return render_template("platform/company_form.html", company=company, form=form)


@bp.route("/entreprises/<int:company_id>/statut", methods=["POST"])
@superadmin_required
def company_toggle(company_id):
    company = db.session.get(Company, company_id) or abort(404)
    company.is_active = not company.is_active
    audit("statut_entreprise", f"{company.name} -> {'active' if company.is_active else 'suspendue'}",
          company_id=company.id)
    db.session.commit()
    flash(f"Entreprise {'réactivée' if company.is_active else 'suspendue : ses utilisateurs ne peuvent plus se connecter'}.",
          "success")
    return redirect(url_for("platform.company_detail", company_id=company.id))


@bp.route("/entreprises/<int:company_id>/prolonger", methods=["POST"])
@superadmin_required
def company_extend(company_id):
    company = db.session.get(Company, company_id) or abort(404)
    months = to_int(request.form.get("months"), 0)
    if months not in (1, 3, 6, 12):
        flash("Durée invalide.", "danger")
    else:
        start = max(company.subscription_end or utcnow().date(), utcnow().date())
        company.subscription_end = start + timedelta(days=30 * months)
        audit("prolongation_abonnement", f"{company.name} +{months} mois", company_id=company.id)
        db.session.commit()
        flash(f"Abonnement prolongé jusqu'au {company.subscription_end:%d/%m/%Y}.", "success")
    return redirect(url_for("platform.company_detail", company_id=company.id))


@bp.route("/entreprises/<int:company_id>/utilisateurs/<int:user_id>/mot-de-passe", methods=["POST"])
@superadmin_required
def reset_user_password(company_id, user_id):
    user = db.session.get(User, user_id)
    if not user or user.company_id != company_id:
        abort(404)
    password = request.form.get("password", "")
    errors = _password_errors(password)
    if errors:
        for e in errors:
            flash(e, "danger")
    else:
        user.set_password(password)
        user.must_change_password = True
        user.failed_attempts = 0
        user.locked_until = None
        user.is_active_account = True
        audit("reinitialisation_mot_de_passe", user.username, company_id=company_id)
        db.session.commit()
        flash(f"Mot de passe de {user.username} réinitialisé (à changer à la prochaine connexion).", "success")
    return redirect(url_for("platform.company_detail", company_id=company_id))


@bp.route("/entreprises/<int:company_id>/support", methods=["POST"])
@superadmin_required
def enter_support(company_id):
    company = db.session.get(Company, company_id) or abort(404)
    session["support_company_id"] = company.id
    audit("acces_support", f"Ouverture de l'espace {company.name}", company_id=company.id)
    db.session.commit()
    return redirect(url_for("dashboard.index"))


@bp.route("/quitter-support", methods=["POST"])
@superadmin_required
def exit_support():
    session.pop("support_company_id", None)
    return redirect(url_for("platform.index"))


@bp.route("/entreprises/<int:company_id>/logo")
@superadmin_required
def company_logo(company_id):
    from flask import Response
    company = db.session.get(Company, company_id) or abort(404)
    if not company.logo:
        abort(404)
    return Response(company.logo, mimetype=company.logo_mimetype or "image/png",
                    headers={"Cache-Control": "private, max-age=300"})
