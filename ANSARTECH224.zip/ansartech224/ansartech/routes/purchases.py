"""Étape 7 — Achats et fournisseurs."""

from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from ..extensions import db
from ..models import PURCHASE_STATUS, Product, Purchase, PurchaseItem, Supplier
from ..utils import (audit, csv_response, get_setting, move_stock, next_reference,
                     role_required, to_float, to_int)
from ..models import utcnow

bp = Blueprint("purchases", __name__, url_prefix="/achats")


# ---------------------------------------------------------------- Fournisseurs
@bp.route("/fournisseurs")
@login_required
def suppliers():
    q = request.args.get("q", "").strip()
    query = Supplier.query
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Supplier.name.ilike(like), Supplier.phone.ilike(like),
                                    Supplier.contact.ilike(like)))
    return render_template("purchases/suppliers.html", suppliers=query.order_by(Supplier.name).all(), q=q)


@bp.route("/fournisseurs/nouveau", methods=["GET", "POST"])
@bp.route("/fournisseurs/<int:supplier_id>/modifier", methods=["GET", "POST"])
@role_required("gestionnaire")
def supplier_form(supplier_id=None):
    supplier = db.session.get(Supplier, supplier_id) if supplier_id else None
    if supplier_id and not supplier:
        abort(404)
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Le nom du fournisseur est obligatoire.", "danger")
            return render_template("purchases/supplier_form.html", supplier=supplier, form=request.form)
        if supplier is None:
            supplier = Supplier()
            db.session.add(supplier)
        supplier.name = name[:150]
        for field, size in (("contact", 120), ("phone", 30), ("email", 120), ("address", 255)):
            setattr(supplier, field, request.form.get(field, "").strip()[:size])
        supplier.notes = request.form.get("notes", "").strip()
        audit("fournisseur", name)
        db.session.commit()
        flash("Fournisseur enregistré.", "success")
        return redirect(url_for("purchases.supplier_detail", supplier_id=supplier.id))
    return render_template("purchases/supplier_form.html", supplier=supplier, form={})


@bp.route("/fournisseurs/<int:supplier_id>")
@login_required
def supplier_detail(supplier_id):
    supplier = db.session.get(Supplier, supplier_id) or abort(404)
    purchases = Purchase.query.filter_by(supplier_id=supplier.id).order_by(Purchase.created_at.desc()).all()
    valid = [p for p in purchases if p.status != "annule"]
    return render_template("purchases/supplier_detail.html", supplier=supplier, purchases=purchases,
                           total=sum(p.total for p in valid), debt=sum(p.balance for p in valid))


# ---------------------------------------------------------------- Bons d'achat
@bp.route("/")
@login_required
def index():
    status = request.args.get("statut", "")
    page = to_int(request.args.get("page"), 1) or 1
    query = Purchase.query
    if status in PURCHASE_STATUS:
        query = query.filter_by(status=status)
    pagination = query.order_by(Purchase.created_at.desc()).paginate(page=page, per_page=25, error_out=False)
    return render_template("purchases/index.html", pagination=pagination, purchases=pagination.items,
                           status=status, statuses=PURCHASE_STATUS)


def _read_lines(form):
    """Lit les lignes produit envoyées par le formulaire dynamique."""
    lines, errors = [], []
    ids = form.getlist("product_id[]")
    quantities = form.getlist("quantity[]")
    prices = form.getlist("price[]")
    for index, raw_id in enumerate(ids):
        product = db.session.get(Product, to_int(raw_id)) if raw_id else None
        if not product:
            continue
        qty = to_float(quantities[index] if index < len(quantities) else 0)
        price = to_float(prices[index] if index < len(prices) else 0, -1)
        if qty <= 0:
            errors.append(f"Quantité invalide pour {product.name}.")
        if price < 0:
            errors.append(f"Prix invalide pour {product.name}.")
        lines.append((product, qty, price))
    if not lines:
        errors.append("Ajoutez au moins un produit.")
    return lines, errors


@bp.route("/nouveau", methods=["GET", "POST"])
@role_required("gestionnaire")
def create():
    suppliers = Supplier.query.order_by(Supplier.name).all()
    if request.method == "POST":
        supplier = db.session.get(Supplier, to_int(request.form.get("supplier_id")))
        lines, errors = _read_lines(request.form)
        amount_paid = to_float(request.form.get("amount_paid"), 0)
        if not supplier:
            errors.insert(0, "Choisissez un fournisseur.")
        if amount_paid < 0:
            errors.append("Le montant payé ne peut pas être négatif.")
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("purchases/form.html", suppliers=suppliers, form=request.form)

        purchase = Purchase(reference=next_reference(Purchase, "reference", get_setting("purchase_prefix") or "ACH"),
                            supplier=supplier, user_id=current_user.id,
                            notes=request.form.get("notes", "").strip())
        for product, qty, price in lines:
            purchase.items.append(PurchaseItem(product=product, quantity=qty, unit_cost=price))
        purchase.total = round(sum(i.line_total for i in purchase.items), 2)
        purchase.amount_paid = min(amount_paid, purchase.total)
        db.session.add(purchase)
        if request.form.get("receive_now"):
            _receive(purchase, request.form.get("update_cost") == "1")
        audit("creation_achat", purchase.reference)
        db.session.commit()
        flash(f"Bon d'achat {purchase.reference} enregistré.", "success")
        return redirect(url_for("purchases.detail", purchase_id=purchase.id))
    return render_template("purchases/form.html", suppliers=suppliers, form={})


@bp.route("/<int:purchase_id>")
@login_required
def detail(purchase_id):
    purchase = db.session.get(Purchase, purchase_id) or abort(404)
    return render_template("purchases/detail.html", purchase=purchase)


def _receive(purchase, update_cost):
    for item in purchase.items:
        move_stock(item.product, item.quantity, "achat", f"Réception {purchase.supplier.name}",
                   purchase.reference)
        if update_cost and item.unit_cost > 0:
            item.product.purchase_price = item.unit_cost
    purchase.status = "recu"
    purchase.received_at = utcnow()


@bp.route("/<int:purchase_id>/recevoir", methods=["POST"])
@role_required("gestionnaire")
def receive(purchase_id):
    purchase = db.session.get(Purchase, purchase_id) or abort(404)
    if purchase.status != "commande":
        flash("Ce bon n'est plus en attente de réception.", "warning")
    else:
        _receive(purchase, request.form.get("update_cost") == "1")
        audit("reception_achat", purchase.reference)
        db.session.commit()
        flash("Marchandises reçues : le stock a été mis à jour.", "success")
    return redirect(url_for("purchases.detail", purchase_id=purchase.id))


@bp.route("/<int:purchase_id>/annuler", methods=["POST"])
@role_required("gestionnaire")
def cancel(purchase_id):
    purchase = db.session.get(Purchase, purchase_id) or abort(404)
    if purchase.status != "commande":
        flash("Seul un bon non reçu peut être annulé.", "warning")
    else:
        purchase.status = "annule"
        audit("annulation_achat", purchase.reference)
        db.session.commit()
        flash("Bon d'achat annulé.", "success")
    return redirect(url_for("purchases.detail", purchase_id=purchase.id))


@bp.route("/<int:purchase_id>/paiement", methods=["POST"])
@role_required("gestionnaire")
def payment(purchase_id):
    purchase = db.session.get(Purchase, purchase_id) or abort(404)
    amount = to_float(request.form.get("amount"), 0)
    if purchase.status == "annule" or amount <= 0 or amount > purchase.balance + 0.01:
        flash("Montant de paiement invalide.", "danger")
    else:
        purchase.amount_paid = round(purchase.amount_paid + amount, 2)
        audit("paiement_fournisseur", f"{purchase.reference} {amount:g}")
        db.session.commit()
        flash("Paiement fournisseur enregistré.", "success")
    return redirect(url_for("purchases.detail", purchase_id=purchase.id))


@bp.route("/export")
@login_required
def export():
    rows = [(p.reference, p.created_at.strftime("%d/%m/%Y"), p.supplier.name, p.status_label,
             p.total, p.amount_paid, p.balance)
            for p in Purchase.query.order_by(Purchase.created_at.desc())]
    return csv_response("achats.csv", ["Référence", "Date", "Fournisseur", "Statut", "Total",
                                       "Payé", "Reste"], rows)
