"""Étape 4 — Tableau de bord."""
from datetime import timedelta

from flask import Blueprint, render_template
from flask_login import login_required

from ..extensions import db
from ..models import Product, Purchase, Sale
from ..models import utcnow

bp = Blueprint("dashboard", __name__)


def _valid_sales(start, end=None):
    query = Sale.query.filter(Sale.status != "annulee", Sale.created_at >= start)
    if end:
        query = query.filter(Sale.created_at < end)
    return query


@bp.route("/")
@login_required
def index():
    now = utcnow()
    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    month_start = today.replace(day=1)
    chart_start = today - timedelta(days=13)

    today_sales = _valid_sales(today).all()
    month_sales = _valid_sales(month_start).all()
    chart_sales = _valid_sales(chart_start).all()

    products = Product.query.filter_by(is_active=True).all()
    stock_value = sum(p.stock_value for p in products)
    low_stock = sorted([p for p in products if p.quantity <= p.min_stock], key=lambda p: p.quantity)

    daily = {(chart_start + timedelta(days=i)).date(): 0 for i in range(14)}
    for sale in chart_sales:
        day = sale.created_at.date()
        if day in daily:
            daily[day] += sale.total

    receivables = db.session.query(db.func.coalesce(db.func.sum(Sale.total - Sale.amount_paid), 0)).filter(
        Sale.status.in_(["partielle", "impayee"])).scalar()
    pending_purchases = Purchase.query.filter_by(status="commande").count()

    stats = {
        "today_total": sum(s.total for s in today_sales),
        "today_count": len(today_sales),
        "month_total": sum(s.total for s in month_sales),
        "month_profit": sum(s.profit for s in month_sales),
        "stock_value": stock_value,
        "product_count": len(products),
        "receivables": receivables or 0,
        "pending_purchases": pending_purchases,
    }
    recent_sales = Sale.query.order_by(Sale.created_at.desc()).limit(6).all()
    return render_template(
        "dashboard.html",
        stats=stats,
        low_stock=low_stock[:8],
        recent_sales=recent_sales,
        chart_labels=[d.strftime("%d/%m") for d in daily],
        chart_values=[round(v) for v in daily.values()],
    )
