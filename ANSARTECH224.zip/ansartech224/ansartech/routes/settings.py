"""Étape 11 — Paramètres, sécurité, journal et sauvegarde."""
import json
import re

from flask import Blueprint, Response, abort, flash, g, redirect, render_template, request, url_for

from ..extensions import db
from ..models import (COMPANY_FIELDS, DEFAULT_SETTINGS, AuditLog, Category, Company, Customer, Product,
                      Purchase, PurchaseItem, Sale, SaleItem, StockMovement, Supplier, User)
from ..utils import all_settings, audit, role_required, set_setting, to_float, to_int
from ..models import utcnow

bp = Blueprint("settings", __name__, url_prefix="/parametres")

CURRENCIES = ["GNF", "FCFA", "EUR", "USD"]
LOGO_TYPES = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "webp": "image/webp"}
MAX_LOGO_SIZE = 1024 * 1024  # 1 Mo
COMPANY_FIELD_SIZES = {"name": 150, "activity": 150, "address": 255, "city": 80, "country": 80,
                       "phone": 60, "email": 120, "website": 150, "rccm": 80, "nif": 80}
HEX_COLOR = re.compile(r"^#[0-9a-fA-F]{6}$")


def _image_type(data):
    """Vérifie le contenu réel du fichier (et pas seulement son extension)."""
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


@bp.route("/", methods=["GET", "POST"])
@role_required("admin")
def index():
    company = db.session.get(Company, g.company_id) or abort(404)
    if request.method == "POST":
        f = request.form
        errors = []
        tax = to_float(f.get("tax_rate"), -1)
        if tax < 0 or tax > 100:
            errors.append("Le taux de taxe doit être entre 0 et 100.")
        if not f.get("name", "").strip():
            errors.append("Le nom de l'entreprise est obligatoire.")
        if f.get("currency") not in CURRENCIES:
            errors.append("Devise invalide.")
        for key in ("invoice_prefix", "purchase_prefix"):
            value = f.get(key, "").strip().upper()
            if not value.isalnum() or len(value) > 6:
                errors.append("Les préfixes doivent contenir 1 à 6 lettres ou chiffres.")
                break
        color = f.get("invoice_color", "#0b5d43").strip()
        if not HEX_COLOR.match(color):
            errors.append("Couleur de facture invalide.")

        logo_file = request.files.get("logo")
        logo_data = None
        if logo_file and logo_file.filename:
            ext = logo_file.filename.rsplit(".", 1)[-1].lower() if "." in logo_file.filename else ""
            logo_data = logo_file.read()
            if ext not in LOGO_TYPES or not _image_type(logo_data):
                errors.append("Logo : image PNG, JPG ou WEBP uniquement.")
            elif len(logo_data) > MAX_LOGO_SIZE:
                errors.append("Logo trop lourd (1 Mo maximum).")

        if errors:
            for e in errors:
                flash(e, "danger")
            values = all_settings()
            values.update({k: v for k, v in f.items() if k != "csrf_token"})
            return render_template("settings/index.html", values=values, company=company,
                                   currencies=CURRENCIES)

        for field in COMPANY_FIELDS:
            setattr(company, field, f.get(field, "").strip()[:COMPANY_FIELD_SIZES[field]])
        if logo_data:
            company.logo = logo_data
            company.logo_mimetype = _image_type(logo_data)
        if f.get("remove_logo") and not logo_data:
            company.logo = None
            company.logo_mimetype = None

        for key in DEFAULT_SETTINGS:
            if key == "tax_rate":
                set_setting(key, f"{tax:g}")
            elif key in ("invoice_prefix", "purchase_prefix"):
                set_setting(key, f.get(key, "").strip().upper())
            elif key in ("low_stock_alert", "show_logo_on_invoice"):
                set_setting(key, "1" if f.get(key) else "0")
            elif key == "invoice_color":
                set_setting(key, color)
            else:
                set_setting(key, f.get(key, "").strip()[:1000])
        audit("parametres", "Mise à jour des paramètres")
        db.session.commit()
        flash("Paramètres enregistrés.", "success")
        return redirect(url_for("settings.index"))
    return render_template("settings/index.html", values=all_settings(), company=company,
                           currencies=CURRENCIES)


@bp.route("/logo")
def logo():
    """Logo de l'entreprise connectée (utilisé par le menu et les factures)."""
    company = db.session.get(Company, g.get("company_id") or 0)
    if not company or not company.logo:
        abort(404)
    return Response(company.logo, mimetype=company.logo_mimetype or "image/png",
                    headers={"Cache-Control": "private, max-age=300"})


@bp.route("/journal")
@role_required("admin")
def logs():
    page = to_int(request.args.get("page"), 1) or 1
    action = request.args.get("action", "").strip()
    query = AuditLog.query
    if action:
        query = query.filter(AuditLog.action.ilike(f"%{action}%"))
    pagination = query.order_by(AuditLog.created_at.desc()).paginate(page=page, per_page=50, error_out=False)
    return render_template("settings/logs.html", pagination=pagination, logs=pagination.items, action=action)


def _rows(model, exclude=(), query=None):
    result = []
    for obj in (query if query is not None else model.query).all():
        row = {}
        for column in model.__table__.columns:
            if column.name in exclude:
                continue
            value = getattr(obj, column.name)
            row[column.name] = value.isoformat() if hasattr(value, "isoformat") else value
        result.append(row)
    return result


@bp.route("/sauvegarde")
@role_required("admin")
def backup():
    data = {
        "application": "ANSARTECH 224",
        "date": utcnow().isoformat(),
        "parametres": all_settings(),
        "entreprise": _rows(Company, exclude=("logo",), query=Company.query.filter_by(id=g.company_id)),
        "utilisateurs": _rows(User, exclude=("password_hash",)),
        "categories": _rows(Category),
        "produits": _rows(Product),
        "mouvements_stock": _rows(StockMovement),
        "fournisseurs": _rows(Supplier),
        "achats": _rows(Purchase),
        "lignes_achat": _rows(PurchaseItem, query=PurchaseItem.query.join(Purchase)),
        "clients": _rows(Customer),
        "ventes": _rows(Sale),
        "lignes_vente": _rows(SaleItem, query=SaleItem.query.join(Sale)),
    }
    audit("sauvegarde", "Export JSON complet")
    db.session.commit()
    filename = f"sauvegarde_ansartech224_{utcnow():%Y%m%d_%H%M}.json"
    return Response(json.dumps(data, ensure_ascii=False, indent=1), mimetype="application/json",
                    headers={"Content-Disposition": f"attachment; filename={filename}"})
