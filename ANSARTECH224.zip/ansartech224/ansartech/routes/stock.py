"""Étape 6 — Gestion des stocks : mouvements, alertes et inventaire."""
from datetime import timedelta

from flask import Blueprint, flash, redirect, render_template, request, url_for
from flask_login import login_required

from ..extensions import db
from ..models import MOVEMENT_TYPES, Product, StockMovement
from ..utils import audit, csv_response, move_stock, role_required, to_float, to_int
from ..models import utcnow

bp = Blueprint("stock", __name__, url_prefix="/stock")


@bp.route("/")
@login_required
def index():
    movement_type = request.args.get("type", "")
    product_id = to_int(request.args.get("produit"))
    days = to_int(request.args.get("jours"), 30) or 30
    page = to_int(request.args.get("page"), 1) or 1

    query = StockMovement.query.filter(StockMovement.created_at >= utcnow() - timedelta(days=days))
    if movement_type in MOVEMENT_TYPES:
        query = query.filter_by(movement_type=movement_type)
    if product_id:
        query = query.filter_by(product_id=product_id)
    pagination = query.order_by(StockMovement.created_at.desc()).paginate(page=page, per_page=30, error_out=False)

    products = Product.query.filter_by(is_active=True).order_by(Product.name).all()
    alerts = [p for p in products if p.quantity <= p.min_stock]
    return render_template("stock/index.html", pagination=pagination, movements=pagination.items,
                           products=products, alerts=alerts, types=MOVEMENT_TYPES,
                           movement_type=movement_type, product_id=product_id, days=days,
                           total_value=sum(p.stock_value for p in products))


@bp.route("/mouvement", methods=["GET", "POST"])
@role_required("gestionnaire")
def movement():
    products = Product.query.filter_by(is_active=True).order_by(Product.name).all()
    if request.method == "POST":
        product = db.session.get(Product, to_int(request.form.get("product_id")))
        kind = request.form.get("movement_type")
        qty = to_float(request.form.get("quantity"), -1)
        reason = request.form.get("reason", "").strip()
        errors = []
        if not product:
            errors.append("Choisissez un produit.")
        if kind not in ("entree", "sortie", "ajustement"):
            errors.append("Type de mouvement invalide.")
        if qty < 0 or (kind != "ajustement" and qty == 0):
            errors.append("Quantité invalide.")
        if not reason:
            errors.append("Indiquez le motif du mouvement.")
        if product and kind == "sortie" and qty > product.quantity:
            errors.append(f"Stock insuffisant : {product.quantity:g} {product.unit} disponible(s).")
        if errors:
            for e in errors:
                flash(e, "danger")
            return render_template("stock/movement.html", products=products, form=request.form)

        if kind == "entree":
            delta = qty
        elif kind == "sortie":
            delta = -qty
        else:  # ajustement : la quantité saisie est le stock réel compté
            delta = qty - product.quantity
        if delta == 0:
            flash("Aucun changement : le stock est déjà à cette valeur.", "info")
            return redirect(url_for("stock.index"))
        move_stock(product, delta, kind, reason)
        audit("mouvement_stock", f"{product.sku} {kind} {delta:+g}")
        db.session.commit()
        flash(f"Stock de « {product.name} » mis à jour : {product.quantity:g} {product.unit}.", "success")
        return redirect(url_for("stock.index"))

    return render_template("stock/movement.html", products=products,
                           form={"product_id": request.args.get("produit", "")})


@bp.route("/inventaire", methods=["GET", "POST"])
@role_required("gestionnaire")
def inventory():
    products = Product.query.filter_by(is_active=True).order_by(Product.name).all()
    if request.method == "POST":
        changed = 0
        for product in products:
            raw = request.form.get(f"count_{product.id}", "").strip()
            if raw == "":
                continue
            counted = to_float(raw, -1)
            if counted < 0:
                flash(f"Quantité invalide pour {product.name}.", "danger")
                db.session.rollback()
                return render_template("stock/inventory.html", products=products)
            delta = counted - product.quantity
            if delta != 0:
                move_stock(product, delta, "ajustement", "Inventaire physique",
                           f"INV-{utcnow():%Y%m%d}")
                changed += 1
        audit("inventaire", f"{changed} produit(s) ajusté(s)")
        db.session.commit()
        flash(f"Inventaire enregistré : {changed} produit(s) ajusté(s).", "success")
        return redirect(url_for("stock.index"))
    return render_template("stock/inventory.html", products=products)


@bp.route("/export")
@login_required
def export():
    rows = [(m.created_at.strftime("%d/%m/%Y %H:%M"), m.product.sku, m.product.name, m.type_label,
             m.quantity, m.stock_after, m.reason, m.reference, m.user.full_name if m.user else "")
            for m in StockMovement.query.order_by(StockMovement.created_at.desc()).limit(5000)]
    return csv_response("mouvements_stock.csv", ["Date", "Code", "Produit", "Type", "Quantité",
                                                 "Stock après", "Motif", "Référence", "Utilisateur"], rows)
