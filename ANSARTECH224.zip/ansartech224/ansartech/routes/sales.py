"""Étape 8 — Ventes, clients et facturation."""
from datetime import datetime, timedelta

from flask import Blueprint, abort, flash, redirect, render_template, request, url_for
from flask_login import current_user, login_required

from ..extensions import db
from ..models import PAYMENT_METHODS, SALE_STATUS, Customer, Product, Sale, SaleItem
from ..utils import (audit, csv_response, get_setting, move_stock, next_reference,
                     role_required, to_float, to_int)
from ..models import utcnow

bp = Blueprint("sales", __name__, url_prefix="/ventes")


def _parse_date(value):
    try:
        return datetime.strptime(value, "%Y-%m-%d")
    except (TypeError, ValueError):
        return None


def _filtered_query():
    q = request.args.get("q", "").strip()
    status = request.args.get("statut", "")
    start = _parse_date(request.args.get("du"))
    end = _parse_date(request.args.get("au"))
    query = Sale.query
    if q:
        like = f"%{q}%"
        query = query.outerjoin(Customer).filter(db.or_(Sale.invoice_number.ilike(like),
                                                        Customer.name.ilike(like),
                                                        Customer.phone.ilike(like)))
    if status in SALE_STATUS:
        query = query.filter(Sale.status == status)
    if start:
        query = query.filter(Sale.created_at >= start)
    if end:
        query = query.filter(Sale.created_at < end + timedelta(days=1))
    return query


@bp.route("/")
@login_required
def index():
    page = to_int(request.args.get("page"), 1) or 1
    query = _filtered_query()
    valid = query.filter(Sale.status != "annulee")
    total = valid.with_entities(db.func.coalesce(db.func.sum(Sale.total), 0)).scalar()
    pagination = query.order_by(Sale.created_at.desc()).paginate(page=page, per_page=25, error_out=False)
    return render_template("sales/index.html", pagination=pagination, sales=pagination.items,
                           statuses=SALE_STATUS, total=total or 0, args=request.args)


@bp.route("/export")
@login_required
def export():
    rows = [(s.invoice_number, s.created_at.strftime("%d/%m/%Y %H:%M"),
             s.customer.name if s.customer else "Client comptant", s.status_label, s.payment_label,
             s.subtotal, s.discount, s.tax_amount, s.total, s.amount_paid, s.balance,
             s.user.full_name if s.user else "")
            for s in _filtered_query().order_by(Sale.created_at.desc()).limit(10000)]
    return csv_response("ventes.csv", ["Facture", "Date", "Client", "Statut", "Paiement", "Sous-total",
                                       "Remise", "Taxe", "Total", "Payé", "Reste", "Vendeur"], rows)


@bp.route("/nouvelle", methods=["GET", "POST"])
@role_required("gestionnaire", "vendeur")
def create():
    customers = Customer.query.order_by(Customer.name).all()
    tax_rate = to_float(get_setting("tax_rate"), 0)
    if request.method == "POST":
        f = request.form
        errors, lines = [], []
        requested = {}
        ids = f.getlist("product_id[]")
        quantities = f.getlist("quantity[]")
        prices = f.getlist("price[]")
        for index, raw_id in enumerate(ids):
            product = db.session.get(Product, to_int(raw_id)) if raw_id else None
            if not product or not product.is_active:
                continue
            qty = to_float(quantities[index] if index < len(quantities) else 0)
            price = to_float(prices[index] if index < len(prices) else 0, -1)
            if qty <= 0:
                errors.append(f"Quantité invalide pour {product.name}.")
                continue
            if price < 0:
                errors.append(f"Prix invalide pour {product.name}.")
                continue
            requested[product.id] = requested.get(product.id, 0) + qty
            lines.append((product, qty, price))
        if not lines and not errors:
            errors.append("Ajoutez au moins un produit à la vente.")
        for product_id, qty in requested.items():
            product = db.session.get(Product, product_id)
            if qty > product.quantity:
                errors.append(f"Stock insuffisant pour {product.name} : {product.quantity:g} disponible(s).")

        customer = None
        new_customer_name = f.get("new_customer_name", "").strip()
        if new_customer_name:
            customer = Customer(name=new_customer_name[:150], phone=f.get("new_customer_phone", "").strip()[:30])
            db.session.add(customer)
        elif f.get("customer_id"):
            customer = db.session.get(Customer, to_int(f.get("customer_id")))

        payment_method = f.get("payment_method", "especes")
        if payment_method not in PAYMENT_METHODS:
            errors.append("Mode de paiement invalide.")
        discount = to_float(f.get("discount"), 0)
        subtotal = round(sum(q * p for _, q, p in lines), 2)
        if discount < 0 or discount > subtotal:
            errors.append("La remise doit être comprise entre 0 et le sous-total.")
        tax_amount = round((subtotal - discount) * tax_rate / 100, 2)
        total = round(subtotal - discount + tax_amount, 2)
        paid_raw = f.get("amount_paid", "").strip()
        amount_paid = total if paid_raw == "" else to_float(paid_raw, -1)
        if amount_paid < 0:
            errors.append("Montant payé invalide.")
        if amount_paid < total and not customer:
            errors.append("Une vente à crédit ou partielle nécessite un client identifié.")

        if errors:
            db.session.rollback()
            for e in errors:
                flash(e, "danger")
            return render_template("sales/form.html", customers=customers, tax_rate=tax_rate,
                                   payment_methods=PAYMENT_METHODS, form=f)

        change = max(amount_paid - total, 0)
        amount_paid = min(amount_paid, total)
        sale = Sale(invoice_number=next_reference(Sale, "invoice_number", get_setting("invoice_prefix") or "FAC"),
                    customer=customer, subtotal=subtotal, discount=discount, tax_rate=tax_rate,
                    tax_amount=tax_amount, total=total, amount_paid=amount_paid,
                    payment_method=payment_method, user_id=current_user.id,
                    notes=f.get("notes", "").strip())
        sale.status = "payee" if amount_paid >= total else ("impayee" if amount_paid == 0 else "partielle")
        for product, qty, price in lines:
            sale.items.append(SaleItem(product=product, quantity=qty, unit_price=price,
                                       unit_cost=product.purchase_price))
            move_stock(product, -qty, "vente", "Vente", sale.invoice_number)
        db.session.add(sale)
        audit("vente", f"{sale.invoice_number} total={total:g}")
        db.session.commit()
        message = f"Vente {sale.invoice_number} enregistrée."
        if change > 0:
            message += f" Monnaie à rendre : {change:,.0f}".replace(",", " ") + f" {get_setting('currency')}."
        flash(message, "success")
        return redirect(url_for("sales.detail", sale_id=sale.id))

    return render_template("sales/form.html", customers=customers, tax_rate=tax_rate,
                           payment_methods=PAYMENT_METHODS, form={})


@bp.route("/<int:sale_id>")
@login_required
def detail(sale_id):
    sale = db.session.get(Sale, sale_id) or abort(404)
    return render_template("sales/detail.html", sale=sale)


@bp.route("/<int:sale_id>/facture")
@login_required
def invoice(sale_id):
    sale = db.session.get(Sale, sale_id) or abort(404)
    return render_template("sales/invoice.html", sale=sale, ticket=request.args.get("format") == "ticket")


@bp.route("/<int:sale_id>/paiement", methods=["POST"])
@role_required("gestionnaire", "vendeur")
def payment(sale_id):
    sale = db.session.get(Sale, sale_id) or abort(404)
    amount = to_float(request.form.get("amount"), 0)
    if sale.status == "annulee" or amount <= 0 or amount > sale.balance + 0.01:
        flash("Montant invalide.", "danger")
    else:
        sale.amount_paid = round(sale.amount_paid + amount, 2)
        sale.status = "payee" if sale.amount_paid >= sale.total - 0.01 else "partielle"
        audit("paiement_client", f"{sale.invoice_number} {amount:g}")
        db.session.commit()
        flash("Paiement enregistré.", "success")
    return redirect(url_for("sales.detail", sale_id=sale.id))


@bp.route("/<int:sale_id>/annuler", methods=["POST"])
@role_required("gestionnaire")
def cancel(sale_id):
    sale = db.session.get(Sale, sale_id) or abort(404)
    reason = request.form.get("reason", "").strip()
    if sale.status == "annulee":
        flash("Cette vente est déjà annulée.", "warning")
    elif not reason:
        flash("Indiquez le motif de l'annulation.", "danger")
    else:
        for item in sale.items:
            move_stock(item.product, item.quantity, "retour", f"Annulation : {reason}", sale.invoice_number)
        sale.status = "annulee"
        sale.notes = ((sale.notes or "") + f"\nAnnulée le {utcnow():%d/%m/%Y} : {reason}").strip()
        audit("annulation_vente", f"{sale.invoice_number} : {reason}")
        db.session.commit()
        flash("Vente annulée : les produits ont été remis en stock.", "success")
    return redirect(url_for("sales.detail", sale_id=sale.id))


# ---------------------------------------------------------------- Clients
@bp.route("/clients")
@login_required
def customers():
    q = request.args.get("q", "").strip()
    query = Customer.query
    if q:
        like = f"%{q}%"
        query = query.filter(db.or_(Customer.name.ilike(like), Customer.phone.ilike(like)))
    return render_template("sales/customers.html", customers=query.order_by(Customer.name).all(), q=q)


@bp.route("/clients/nouveau", methods=["GET", "POST"])
@bp.route("/clients/<int:customer_id>/modifier", methods=["GET", "POST"])
@login_required
def customer_form(customer_id=None):
    customer = db.session.get(Customer, customer_id) if customer_id else None
    if customer_id and not customer:
        abort(404)
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if not name:
            flash("Le nom du client est obligatoire.", "danger")
            return render_template("sales/customer_form.html", customer=customer, form=request.form)
        if customer is None:
            customer = Customer()
            db.session.add(customer)
        customer.name = name[:150]
        customer.phone = request.form.get("phone", "").strip()[:30]
        customer.email = request.form.get("email", "").strip()[:120]
        customer.address = request.form.get("address", "").strip()[:255]
        db.session.commit()
        flash("Client enregistré.", "success")
        return redirect(url_for("sales.customer_detail", customer_id=customer.id))
    return render_template("sales/customer_form.html", customer=customer, form={})


@bp.route("/clients/<int:customer_id>")
@login_required
def customer_detail(customer_id):
    customer = db.session.get(Customer, customer_id) or abort(404)
    sales = Sale.query.filter_by(customer_id=customer.id).order_by(Sale.created_at.desc()).all()
    valid = [s for s in sales if s.status != "annulee"]
    return render_template("sales/customer_detail.html", customer=customer, sales=sales,
                           total=sum(s.total for s in valid), debt=sum(s.balance for s in valid))
