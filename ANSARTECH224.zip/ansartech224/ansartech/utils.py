"""Fonctions utilitaires partagées."""
import csv
import io
from functools import wraps

from flask import Response, abort, flash, redirect, request, url_for
from flask_login import current_user

from .extensions import db
from .models import COMPANY_FIELDS, DEFAULT_SETTINGS, AuditLog, Company, Setting, StockMovement
from .models import utcnow  # noqa: F401
from .tenancy import current_company_id


# ---------------------------------------------------------------- Rôles
def role_required(*roles):
    """Restreint une page aux rôles donnés (l'administrateur de l'entreprise a toujours accès)."""
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not current_user.is_authenticated:
                return redirect(url_for("auth.login", next=request.path))
            role = current_user.effective_role
            if role != "admin" and role not in roles:
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


def superadmin_required(view):
    """Réservé au propriétaire de la plateforme."""
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user.is_authenticated:
            return redirect(url_for("auth.login", next=request.path))
        if current_user.role != "superadmin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped


# ---------------------------------------------------------------- Journal d'audit
def audit(action, details="", company_id=None):
    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "")
    ip = ip.split(",")[0].strip()[:60]
    user_id = current_user.id if current_user and current_user.is_authenticated else None
    if company_id is None:
        company_id = current_company_id()
        if company_id is None and current_user and current_user.is_authenticated:
            company_id = current_user.company_id
    db.session.add(AuditLog(user_id=user_id, company_id=company_id, action=action[:80],
                            details=(details or "")[:500], ip_address=ip))


# ---------------------------------------------------------------- Entreprise et paramètres
def current_company():
    company_id = current_company_id()
    return db.session.get(Company, company_id) if company_id else None


def get_setting(key):
    row = Setting.query.filter_by(key=key).first() if current_company_id() else None
    if row is None or row.value is None:
        return DEFAULT_SETTINGS.get(key, "")
    return row.value


def all_settings():
    """Paramètres de l'entreprise active, avec sa fiche (nom, adresses…)."""
    data = dict(DEFAULT_SETTINGS)
    company = current_company()
    if company is None:
        data.update(company_name="ANSARTECH 224", company_address="", company_phone="",
                    company_email="", company_rccm="")
        return data
    for row in Setting.query.all():
        data[row.key] = row.value or ""
    for field in COMPANY_FIELDS:
        data["company_" + field] = getattr(company, field) or ""
    data["company_address"] = company.full_address
    data["company_street"] = company.address or ""
    # Coordonnées imprimées sur la facture (par défaut : celles de l'entreprise)
    data["invoice_address_display"] = data["invoice_address"] or company.full_address
    data["invoice_phone_display"] = data["invoice_phone"] or (company.phone or "")
    data["invoice_email_display"] = data["invoice_email"] or (company.email or "")
    return data


def set_setting(key, value):
    row = Setting.query.filter_by(key=key).first()
    if row is None:
        db.session.add(Setting(key=key, value=value))
    else:
        row.value = value


# ---------------------------------------------------------------- Saisie
def to_float(value, default=0.0):
    if value is None:
        return default
    text = str(value).replace(" ", "").replace("\xa0", "").replace(" ", "").replace(",", ".").strip()
    if not text:
        return default
    try:
        return float(text)
    except ValueError:
        return default


def to_int(value, default=None):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------- Numérotation
def next_reference(model, field, prefix):
    """Génère FAC-2026-00001, ACH-2026-00001, etc."""
    year = utcnow().year
    base = f"{prefix}-{year}-"
    column = getattr(model, field)
    last = (db.session.query(column).filter(column.like(base + "%"))
            .order_by(column.desc()).first())
    number = 1
    if last and last[0]:
        try:
            number = int(last[0].rsplit("-", 1)[1]) + 1
        except (IndexError, ValueError):
            number = model.query.count() + 1
    return f"{base}{number:05d}"


# ---------------------------------------------------------------- Stock
def move_stock(product, quantity, movement_type, reason="", reference=""):
    """Modifie le stock d'un produit et enregistre le mouvement.

    quantity > 0 : entrée ; quantity < 0 : sortie.
    """
    product.quantity = round((product.quantity or 0) + quantity, 3)
    movement = StockMovement(
        product=product,
        movement_type=movement_type,
        quantity=quantity,
        stock_after=product.quantity,
        reason=reason[:255] if reason else "",
        reference=reference[:60] if reference else "",
        user_id=current_user.id if current_user and current_user.is_authenticated else None,
    )
    db.session.add(movement)
    return movement


# ---------------------------------------------------------------- Export CSV
def csv_response(filename, headers, rows):
    buffer = io.StringIO()
    buffer.write("﻿")  # BOM pour qu'Excel lise bien les accents
    writer = csv.writer(buffer, delimiter=";")
    writer.writerow(headers)
    for row in rows:
        writer.writerow(row)
    return Response(
        buffer.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


def flash_errors(errors):
    for error in errors:
        flash(error, "danger")


def money(value, currency=None):
    try:
        number = float(value or 0)
    except (TypeError, ValueError):
        number = 0
    text = f"{number:,.0f}".replace(",", " ")
    if currency is None:
        currency = get_setting("currency")
    return f"{text} {currency}".strip()


def number(value):
    try:
        number_value = float(value or 0)
    except (TypeError, ValueError):
        return "0"
    if number_value == int(number_value):
        return f"{int(number_value):,}".replace(",", " ")
    return f"{number_value:,.2f}".replace(",", " ")
