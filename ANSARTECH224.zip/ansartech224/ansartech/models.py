"""Étape 2 — Base de données : tous les modèles de ANSARTECH 224."""
from datetime import datetime, timezone

from flask_login import UserMixin
from werkzeug.security import check_password_hash, generate_password_hash

from .extensions import db, login_manager


def utcnow():
    """Date et heure UTC (Conakry est à UTC+0)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def now():
    return utcnow()


# ---------------------------------------------------------------- Multi-entreprises
class TenantMixin:
    """Toute table qui appartient à une entreprise (isolation automatique)."""

    @db.declared_attr
    def company_id(cls):
        return db.Column(db.Integer, db.ForeignKey("companies.id"), nullable=False, index=True)


class Company(db.Model):
    """Une entreprise cliente de la plateforme ANSARTECH 224."""
    __tablename__ = "companies"
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(30), unique=True, nullable=False, index=True)
    name = db.Column(db.String(150), nullable=False)
    activity = db.Column(db.String(150))
    # Adresse principale (siège)
    address = db.Column(db.String(255))
    city = db.Column(db.String(80), default="Conakry")
    country = db.Column(db.String(80), default="Guinée")
    phone = db.Column(db.String(60))
    email = db.Column(db.String(120))
    website = db.Column(db.String(150))
    rccm = db.Column(db.String(80))
    nif = db.Column(db.String(80))
    # Logo (stocké en base)
    logo = db.Column(db.LargeBinary)
    logo_mimetype = db.Column(db.String(60))
    # Abonnement
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    subscription_end = db.Column(db.Date)
    max_users = db.Column(db.Integer, default=10, nullable=False)
    contact_name = db.Column(db.String(120))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=now)

    @property
    def is_expired(self):
        return bool(self.subscription_end and self.subscription_end < utcnow().date())

    @property
    def can_login(self):
        return self.is_active and not self.is_expired

    @property
    def full_address(self):
        parts = [self.address, self.city, self.country]
        return ", ".join(p for p in parts if p)


TENANT_ROLES = {
    "admin": "Administrateur",
    "gestionnaire": "Gestionnaire",
    "vendeur": "Vendeur",
}

# ---------------------------------------------------------------- Utilisateurs
ROLES = {
    "admin": "Administrateur",
    "gestionnaire": "Gestionnaire",
    "vendeur": "Vendeur",
    "superadmin": "Super-admin plateforme",
}


class User(UserMixin, db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    # vide uniquement pour le super-administrateur de la plateforme
    company_id = db.Column(db.Integer, db.ForeignKey("companies.id"), index=True)
    company = db.relationship("Company")
    username = db.Column(db.String(50), unique=True, nullable=False, index=True)
    full_name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120))
    phone = db.Column(db.String(30))
    password_hash = db.Column(db.String(256), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="vendeur")
    is_active_account = db.Column(db.Boolean, default=True, nullable=False)
    must_change_password = db.Column(db.Boolean, default=False, nullable=False)
    failed_attempts = db.Column(db.Integer, default=0, nullable=False)
    locked_until = db.Column(db.DateTime)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=now)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    @property
    def is_active(self):
        return self.is_active_account

    @property
    def effective_role(self):
        """Le super-administrateur agit comme administrateur dans l'espace d'une entreprise (support)."""
        if self.role == "superadmin":
            from flask import g, has_request_context
            if has_request_context() and getattr(g, "company_id", None):
                return "admin"
        return self.role

    @property
    def is_superadmin(self):
        return self.role == "superadmin"

    @property
    def role_label(self):
        if self.role == "superadmin" and self.effective_role == "admin":
            return "Super-admin (support)"
        return ROLES.get(self.role, self.role)

    def has_role(self, *roles):
        return self.effective_role in roles


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


# ---------------------------------------------------------------- Produits
class Category(TenantMixin, db.Model):
    __tablename__ = "categories"
    __table_args__ = (db.UniqueConstraint("company_id", "name"),)
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    products = db.relationship("Product", back_populates="category")


class Product(TenantMixin, db.Model):
    __tablename__ = "products"
    __table_args__ = (db.UniqueConstraint("company_id", "sku"),)
    id = db.Column(db.Integer, primary_key=True)
    sku = db.Column(db.String(40), nullable=False, index=True)
    barcode = db.Column(db.String(60))
    name = db.Column(db.String(150), nullable=False, index=True)
    description = db.Column(db.Text)
    category_id = db.Column(db.Integer, db.ForeignKey("categories.id"))
    category = db.relationship("Category", back_populates="products")
    unit = db.Column(db.String(20), default="pièce")
    purchase_price = db.Column(db.Float, default=0, nullable=False)
    sale_price = db.Column(db.Float, default=0, nullable=False)
    quantity = db.Column(db.Float, default=0, nullable=False)
    min_stock = db.Column(db.Float, default=5, nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    created_at = db.Column(db.DateTime, default=now)
    updated_at = db.Column(db.DateTime, default=now, onupdate=now)

    @property
    def stock_value(self):
        return (self.quantity or 0) * (self.purchase_price or 0)

    @property
    def margin(self):
        return (self.sale_price or 0) - (self.purchase_price or 0)

    @property
    def margin_rate(self):
        if not self.sale_price:
            return 0
        return self.margin / self.sale_price * 100

    @property
    def stock_status(self):
        if self.quantity <= 0:
            return "rupture"
        if self.quantity <= self.min_stock:
            return "bas"
        return "ok"


# ---------------------------------------------------------------- Stocks
MOVEMENT_TYPES = {
    "entree": "Entrée",
    "sortie": "Sortie",
    "ajustement": "Ajustement",
    "achat": "Réception achat",
    "vente": "Vente",
    "retour": "Retour / annulation",
}


class StockMovement(TenantMixin, db.Model):
    __tablename__ = "stock_movements"
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False, index=True)
    product = db.relationship("Product")
    movement_type = db.Column(db.String(20), nullable=False)
    quantity = db.Column(db.Float, nullable=False)  # positif = entrée, négatif = sortie
    stock_after = db.Column(db.Float, nullable=False)
    reason = db.Column(db.String(255))
    reference = db.Column(db.String(60))
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    user = db.relationship("User")
    created_at = db.Column(db.DateTime, default=now, index=True)

    @property
    def type_label(self):
        return MOVEMENT_TYPES.get(self.movement_type, self.movement_type)


# ---------------------------------------------------------------- Achats
class Supplier(TenantMixin, db.Model):
    __tablename__ = "suppliers"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    contact = db.Column(db.String(120))
    phone = db.Column(db.String(30))
    email = db.Column(db.String(120))
    address = db.Column(db.String(255))
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=now)
    purchases = db.relationship("Purchase", back_populates="supplier")


PURCHASE_STATUS = {"commande": "Commandé", "recu": "Reçu", "annule": "Annulé"}


class Purchase(TenantMixin, db.Model):
    __tablename__ = "purchases"
    __table_args__ = (db.UniqueConstraint("company_id", "reference"),)
    id = db.Column(db.Integer, primary_key=True)
    reference = db.Column(db.String(40), nullable=False)
    supplier_id = db.Column(db.Integer, db.ForeignKey("suppliers.id"), nullable=False)
    supplier = db.relationship("Supplier", back_populates="purchases")
    status = db.Column(db.String(20), default="commande", nullable=False)
    total = db.Column(db.Float, default=0, nullable=False)
    amount_paid = db.Column(db.Float, default=0, nullable=False)
    notes = db.Column(db.Text)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    user = db.relationship("User")
    created_at = db.Column(db.DateTime, default=now, index=True)
    received_at = db.Column(db.DateTime)
    items = db.relationship("PurchaseItem", back_populates="purchase", cascade="all, delete-orphan")

    @property
    def status_label(self):
        return PURCHASE_STATUS.get(self.status, self.status)

    @property
    def balance(self):
        return max(self.total - self.amount_paid, 0)


class PurchaseItem(db.Model):
    __tablename__ = "purchase_items"
    id = db.Column(db.Integer, primary_key=True)
    purchase_id = db.Column(db.Integer, db.ForeignKey("purchases.id"), nullable=False)
    purchase = db.relationship("Purchase", back_populates="items")
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    product = db.relationship("Product")
    quantity = db.Column(db.Float, nullable=False)
    unit_cost = db.Column(db.Float, nullable=False)

    @property
    def line_total(self):
        return self.quantity * self.unit_cost


# ---------------------------------------------------------------- Ventes
class Customer(TenantMixin, db.Model):
    __tablename__ = "customers"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    phone = db.Column(db.String(30))
    email = db.Column(db.String(120))
    address = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=now)
    sales = db.relationship("Sale", back_populates="customer")


SALE_STATUS = {"payee": "Payée", "partielle": "Partielle", "impayee": "Impayée", "annulee": "Annulée"}
PAYMENT_METHODS = {
    "especes": "Espèces",
    "orange_money": "Orange Money",
    "mtn_momo": "MTN Mobile Money",
    "carte": "Carte bancaire",
    "virement": "Virement",
    "credit": "Crédit client",
}


class Sale(TenantMixin, db.Model):
    __tablename__ = "sales"
    __table_args__ = (db.UniqueConstraint("company_id", "invoice_number"),)
    id = db.Column(db.Integer, primary_key=True)
    invoice_number = db.Column(db.String(40), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey("customers.id"))
    customer = db.relationship("Customer", back_populates="sales")
    subtotal = db.Column(db.Float, default=0, nullable=False)
    discount = db.Column(db.Float, default=0, nullable=False)
    tax_rate = db.Column(db.Float, default=0, nullable=False)
    tax_amount = db.Column(db.Float, default=0, nullable=False)
    total = db.Column(db.Float, default=0, nullable=False)
    amount_paid = db.Column(db.Float, default=0, nullable=False)
    payment_method = db.Column(db.String(30), default="especes")
    status = db.Column(db.String(20), default="payee", nullable=False)
    notes = db.Column(db.Text)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    user = db.relationship("User")
    created_at = db.Column(db.DateTime, default=now, index=True)
    items = db.relationship("SaleItem", back_populates="sale", cascade="all, delete-orphan")

    @property
    def status_label(self):
        return SALE_STATUS.get(self.status, self.status)

    @property
    def payment_label(self):
        return PAYMENT_METHODS.get(self.payment_method, self.payment_method)

    @property
    def balance(self):
        return max(self.total - self.amount_paid, 0)

    @property
    def profit(self):
        cost = sum(i.quantity * i.unit_cost for i in self.items)
        return self.subtotal - self.discount - cost


class SaleItem(db.Model):
    __tablename__ = "sale_items"
    id = db.Column(db.Integer, primary_key=True)
    sale_id = db.Column(db.Integer, db.ForeignKey("sales.id"), nullable=False)
    sale = db.relationship("Sale", back_populates="items")
    product_id = db.Column(db.Integer, db.ForeignKey("products.id"), nullable=False)
    product = db.relationship("Product")
    quantity = db.Column(db.Float, nullable=False)
    unit_price = db.Column(db.Float, nullable=False)
    unit_cost = db.Column(db.Float, default=0, nullable=False)  # coût d'achat figé au moment de la vente

    @property
    def line_total(self):
        return self.quantity * self.unit_price


# ---------------------------------------------------------------- Archives & échanges
DOC_CATEGORIES = {
    "facture": "Facture",
    "bon_commande": "Bon de commande",
    "contrat": "Contrat",
    "administratif": "Administratif",
    "rapport": "Rapport",
    "autre": "Autre",
}


class Document(TenantMixin, db.Model):
    __tablename__ = "documents"
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(30), default="autre")
    description = db.Column(db.Text)
    original_name = db.Column(db.String(255), nullable=False)
    mimetype = db.Column(db.String(120))
    size = db.Column(db.Integer, default=0)
    data = db.Column(db.LargeBinary, nullable=False)
    uploaded_by = db.Column(db.Integer, db.ForeignKey("users.id"))
    uploader = db.relationship("User")
    created_at = db.Column(db.DateTime, default=now, index=True)

    @property
    def category_label(self):
        return DOC_CATEGORIES.get(self.category, self.category)


class Message(TenantMixin, db.Model):
    __tablename__ = "messages"
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    sender = db.relationship("User", foreign_keys=[sender_id])
    recipient_id = db.Column(db.Integer, db.ForeignKey("users.id"))  # vide = tout le monde
    recipient = db.relationship("User", foreign_keys=[recipient_id])
    subject = db.Column(db.String(200), nullable=False)
    body = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=now, index=True)


# ---------------------------------------------------------------- Paramètres & sécurité
class Setting(TenantMixin, db.Model):
    __tablename__ = "settings"
    __table_args__ = (db.UniqueConstraint("company_id", "key"),)
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(60), nullable=False)
    value = db.Column(db.Text)


DEFAULT_SETTINGS = {
    "currency": "GNF",
    "tax_rate": "0",
    "invoice_prefix": "FAC",
    "purchase_prefix": "ACH",
    "invoice_title": "FACTURE",
    "invoice_address": "",
    "invoice_phone": "",
    "invoice_email": "",
    "invoice_payment_info": "",
    "invoice_terms": "",
    "invoice_footer": "Merci pour votre confiance. Les marchandises vendues ne sont ni reprises ni échangées.",
    "invoice_color": "#0b5d43",
    "show_logo_on_invoice": "1",
    "low_stock_alert": "1",
}

# Clés tirées de la fiche entreprise (fusionnées dans les paramètres)
COMPANY_FIELDS = ("name", "activity", "address", "city", "country", "phone", "email",
                  "website", "rccm", "nif")


class AuditLog(db.Model):
    __tablename__ = "audit_logs"
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey("companies.id"), index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"))
    user = db.relationship("User")
    action = db.Column(db.String(80), nullable=False)
    details = db.Column(db.String(500))
    ip_address = db.Column(db.String(60))
    created_at = db.Column(db.DateTime, default=now, index=True)
